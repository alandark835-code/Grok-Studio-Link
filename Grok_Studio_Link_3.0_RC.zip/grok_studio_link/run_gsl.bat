@echo off
chcp 65001 >nul
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo No hay .venv. Ejecuta primero install_deps.bat
  pause
  exit /b 1
)

call ".venv\Scripts\activate.bat"
echo Iniciando GROK STUDIO LINK...
python run.py
if errorlevel 1 (
  echo.
  echo La app salio con error. Revisa el mensaje de arriba.
  pause
)
