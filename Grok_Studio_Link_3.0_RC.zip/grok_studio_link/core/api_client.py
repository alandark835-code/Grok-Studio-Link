"""
Optional HTTP API client for API MODE.
Uses httpx when available. Does not invent model names — user must set model/endpoint.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from core.logger import get_logger

log = get_logger()

try:
    import httpx
    _HTTPX = True
except ImportError:
    _HTTPX = False


class APIClientError(Exception):
    pass


class APIClient:
    def __init__(self, endpoint: str, api_key: str, model: str = "", timeout: float = 60.0):
        self.endpoint = endpoint.rstrip("/")
        self.api_key = api_key
        self.model = model
        self.timeout = timeout

    def is_available(self) -> bool:
        return _HTTPX and bool(self.endpoint and self.api_key)

    def chat(self, user_message: str, system: str = "") -> Dict[str, Any]:
        """
        Minimal chat-completions style request.
        Endpoint should be the full base (e.g. https://api.example.com/v1).
        Path used: /chat/completions (OpenAI-compatible). Adjust when provider docs differ.
        """
        if not _HTTPX:
            raise APIClientError("httpx no está instalado. pip install httpx")
        if not self.api_key:
            raise APIClientError("Falta API Key")
        if not self.model:
            raise APIClientError("Falta nombre de modelo (configúralo en Providers)")

        url = f"{self.endpoint}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": user_message})
        body = {
            "model": self.model,
            "messages": messages,
        }
        try:
            with httpx.Client(timeout=self.timeout) as client:
                r = client.post(url, headers=headers, json=body)
            data: Dict[str, Any]
            try:
                data = r.json()
            except Exception:
                data = {"raw": r.text}
            if r.status_code >= 400:
                raise APIClientError(f"HTTP {r.status_code}: {data}")
            return data
        except APIClientError:
            raise
        except Exception as e:
            raise APIClientError(str(e)) from e
