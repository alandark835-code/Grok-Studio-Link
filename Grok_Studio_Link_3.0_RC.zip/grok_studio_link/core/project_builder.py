"""
Project Builder — scaffold Rojo-friendly Roblox project layout.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import List

from core.logger import get_logger
from core.rojo_manager import RojoManager

log = get_logger()


DEFAULT_CONFIG_LUAU = '''-- Shared configuration
local Config = {
	GameName = "MyGame",
	MaxPlayers = 20,
	Debug = true,
}

return Config
'''

DEFAULT_SERVER_LUAU = '''-- Server entry
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config
local ok, result = pcall(function()
	return require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Config"))
end)
if ok then
	Config = result
else
	warn("[Server] Config not found yet:", result)
	Config = { GameName = "MyGame" }
end

print("[Server] Started:", Config.GameName or "MyGame")
'''

DEFAULT_CLIENT_LUAU = '''-- Client entry
print("[Client] Local scripts loaded")
'''


class ProjectBuilder:
    def __init__(self, rojo: RojoManager):
        self.rojo = rojo

    def scaffold(self, project_dir: Path, name: str) -> List[str]:
        """
        Create standard folders + starter scripts + default.project.json.
        Returns list of created/updated relative paths.
        """
        project_dir.mkdir(parents=True, exist_ok=True)
        created: List[str] = []

        mapping = {
            "src/shared/Config.luau": DEFAULT_CONFIG_LUAU,
            "src/server/Main.server.luau": DEFAULT_SERVER_LUAU,
            "src/client/Main.client.luau": DEFAULT_CLIENT_LUAU,
            "README.md": f"# {name}\n\nScaffold generado por GROK STUDIO LINK 3.0 Beta.\n",
        }

        for rel, content in mapping.items():
            path = project_dir / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            if not path.exists():
                path.write_text(content, encoding="utf-8")
                created.append(rel)
                log.info("Scaffold wrote %s", path)

        project_json = self.rojo.init_default_project_json(project_dir, name=name)
        created.append(str(project_json.relative_to(project_dir)).replace("\\", "/"))

        # .gitignore helpful defaults
        gi = project_dir / ".gitignore"
        if not gi.exists():
            gi.write_text("*.rbxlx\n*.rbxl\n.DS_Store\n", encoding="utf-8")
            created.append(".gitignore")

        return created
