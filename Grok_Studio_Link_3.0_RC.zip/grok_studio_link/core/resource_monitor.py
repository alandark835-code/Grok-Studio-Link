"""
Resource Monitor — read-only system metrics skeleton for Alpha 0.1.
Uses only the standard library + optional psutil if installed.
Never kills processes or changes OS priorities.
"""

from __future__ import annotations

import os
import platform
import shutil
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from core.logger import get_logger

log = get_logger()

try:
    import psutil  # type: ignore
    _PSUTIL = True
except ImportError:
    _PSUTIL = False


@dataclass
class ResourceSnapshot:
    available: bool
    source: str  # "psutil" | "stdlib" | "unavailable"
    cpu_percent: Optional[float] = None
    ram_total_gb: Optional[float] = None
    ram_used_gb: Optional[float] = None
    ram_percent: Optional[float] = None
    disk_total_gb: Optional[float] = None
    disk_used_gb: Optional[float] = None
    disk_percent: Optional[float] = None
    process_count: Optional[int] = None
    notes: List[str] = field(default_factory=list)
    platform: str = field(default_factory=lambda: platform.platform())

    def to_dict(self) -> Dict[str, Any]:
        return {
            "available": self.available,
            "source": self.source,
            "cpu_percent": self.cpu_percent,
            "ram_total_gb": self.ram_total_gb,
            "ram_used_gb": self.ram_used_gb,
            "ram_percent": self.ram_percent,
            "disk_total_gb": self.disk_total_gb,
            "disk_used_gb": self.disk_used_gb,
            "disk_percent": self.disk_percent,
            "process_count": self.process_count,
            "notes": self.notes,
            "platform": self.platform,
        }


class ResourceMonitor:
    def snapshot(self) -> ResourceSnapshot:
        if _PSUTIL:
            return self._from_psutil()
        return self._from_stdlib()

    def _from_psutil(self) -> ResourceSnapshot:
        notes = ["Métricas vía psutil (lectura solamente)."]
        try:
            cpu = psutil.cpu_percent(interval=0.3)
            mem = psutil.virtual_memory()
            disk = psutil.disk_usage(os.path.abspath(os.sep))
            return ResourceSnapshot(
                available=True,
                source="psutil",
                cpu_percent=round(cpu, 1),
                ram_total_gb=round(mem.total / (1024**3), 2),
                ram_used_gb=round(mem.used / (1024**3), 2),
                ram_percent=round(mem.percent, 1),
                disk_total_gb=round(disk.total / (1024**3), 2),
                disk_used_gb=round(disk.used / (1024**3), 2),
                disk_percent=round(disk.percent, 1),
                process_count=len(psutil.pids()),
                notes=notes,
            )
        except Exception as e:
            log.warning("psutil snapshot failed: %s", e)
            return ResourceSnapshot(
                available=False,
                source="psutil",
                notes=[f"Error leyendo psutil: {e}"],
            )

    def _from_stdlib(self) -> ResourceSnapshot:
        notes = [
            "psutil no instalado — métricas limitadas con stdlib.",
            "Opcional: pip install psutil",
        ]
        ram_total = ram_used = ram_pct = None
        # Linux-oriented fallback
        try:
            if hasattr(os, "sysconf"):
                total = os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES")
                ram_total = round(total / (1024**3), 2)
        except Exception:
            pass

        disk_total = disk_used = disk_pct = None
        try:
            usage = shutil.disk_usage(os.path.abspath(os.sep))
            disk_total = round(usage.total / (1024**3), 2)
            disk_used = round(usage.used / (1024**3), 2)
            disk_pct = round(100.0 * usage.used / usage.total, 1) if usage.total else None
        except Exception as e:
            notes.append(f"Disco: {e}")

        return ResourceSnapshot(
            available=True,
            source="stdlib",
            ram_total_gb=ram_total,
            ram_used_gb=ram_used,
            ram_percent=ram_pct,
            disk_total_gb=disk_total,
            disk_used_gb=disk_used,
            disk_percent=disk_pct,
            notes=notes,
        )
