"""
Static Luau/Lua analyzer — heuristics only (no full parser).
Produces warnings for common Roblox/Luau issues.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List


@dataclass
class Finding:
    severity: str  # CRITICAL | HIGH | MEDIUM | LOW | INFO
    file: str
    line: int
    code: str
    message: str


@dataclass
class AnalysisReport:
    files_scanned: int = 0
    findings: List[Finding] = field(default_factory=list)

    def by_severity(self) -> dict:
        out: dict = {}
        for f in self.findings:
            out.setdefault(f.severity, []).append(f)
        return out


class LuauAnalyzer:
    """Lightweight regex/line heuristics — not a full Luau typechecker."""

    PATTERNS = [
        # (severity, code, regex, message)
        ("HIGH", "LOADSTRING", re.compile(r"\bloadstring\s*\("), "Uso de loadstring — riesgo de seguridad y a menudo bloqueado"),
        ("HIGH", "GETFENV", re.compile(r"\b(getfenv|setfenv)\s*\("), "getfenv/setfenv no son idiomáticos en Luau moderno"),
        ("MEDIUM", "WAIT_LOOP", re.compile(r"while\s+true\s+do"), "Bucle while true — confirma que hay wait/task.wait y condición de salida"),
        ("MEDIUM", "WAIT_CLASSIC", re.compile(r"(?<![\w.])wait\s*\("), "wait() clásico — preferir task.wait"),
        ("MEDIUM", "SPAWN_CLASSIC", re.compile(r"(?<![\w.])spawn\s*\("), "spawn() clásico — preferir task.spawn"),
        ("MEDIUM", "DELAY_CLASSIC", re.compile(r"(?<![\w.])delay\s*\("), "delay() clásico — preferir task.delay"),
        ("LOW", "PRINT_DEBUG", re.compile(r"\bprint\s*\("), "print() en producción — considera log condicional con Config.Debug"),
        ("HIGH", "HTTP_SERVICE", re.compile(r"HttpService"), "HttpService — revisa filtros y que no se exponga desde el cliente"),
        ("MEDIUM", "REMOTE_CLIENT_FIRE", re.compile(r":FireServer\s*\("), "FireServer — el servidor debe validar todos los argumentos"),
        ("MEDIUM", "REMOTE_INVOKE", re.compile(r":InvokeServer\s*\("), "InvokeServer — valida en servidor; evita devolver datos sensibles de más"),
        ("LOW", "WAIT_FOR_CHILD", re.compile(r":WaitForChild\s*\(\s*[\"'][^\"']+[\"']\s*\)"), "WaitForChild sin timeout — puede colgarse si falta la instancia"),
        ("INFO", "TODO", re.compile(r"\bTODO\b|\bFIXME\b", re.I), "Marcador TODO/FIXME pendiente"),
    ]

    def analyze_tree(self, root: Path) -> AnalysisReport:
        report = AnalysisReport()
        if not root.exists():
            return report
        for path in sorted(root.rglob("*")):
            if not path.is_file():
                continue
            if path.suffix.lower() not in (".lua", ".luau"):
                continue
            report.files_scanned += 1
            rel = str(path.relative_to(root)).replace("\\", "/")
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except Exception:
                report.findings.append(
                    Finding("MEDIUM", rel, 0, "READ", "No se pudo leer el archivo")
                )
                continue
            report.findings.extend(self._analyze_text(rel, text))
        return report

    def _analyze_text(self, rel: str, text: str) -> List[Finding]:
        findings: List[Finding] = []
        lines = text.splitlines()
        for i, line in enumerate(lines, 1):
            stripped = line.strip()
            if stripped.startswith("--"):
                continue
            for severity, code, rx, msg in self.PATTERNS:
                if rx.search(line):
                    findings.append(Finding(severity, rel, i, code, msg))
        # Empty file
        if not text.strip():
            findings.append(Finding("LOW", rel, 1, "EMPTY", "Archivo vacío"))
        return findings
