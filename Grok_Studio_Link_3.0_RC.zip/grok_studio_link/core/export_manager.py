"""
Export Manager — FREE MODE artifacts and safe project packaging.
Never includes API keys or credentials.
"""

from __future__ import annotations

import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.logger import get_logger
from core.project_manager import ProjectManager
from core.ai_provider import AIProviderManager
from core.rojo_manager import RojoManager
from core.resource_monitor import ResourceMonitor

log = get_logger()

# Extensions allowed inside exported source packages
_SOURCE_EXTENSIONS = {
    ".lua", ".luau", ".json", ".md", ".txt", ".toml", ".yaml", ".yml",
    ".project.json", ".css", ".html", ".js", ".ts",
}


class ExportManager:
    def __init__(
        self,
        project_manager: ProjectManager,
        ai: AIProviderManager,
        rojo: RojoManager,
        resources: ResourceMonitor,
        export_dir: Path,
    ):
        self.pm = project_manager
        self.ai = ai
        self.rojo = rojo
        self.resources = resources
        self.export_dir = export_dir
        self.export_dir.mkdir(parents=True, exist_ok=True)

    def _require_project(self) -> Path:
        if not self.pm.current_project:
            raise RuntimeError("No hay proyecto abierto")
        return self.pm.current_project

    def write_project_state(self) -> Path:
        root = self._require_project()
        prov = self.ai.status()
        rojo = self.rojo.detect()
        snap = self.resources.snapshot()

        files: List[str] = []
        for p in sorted(root.rglob("*")):
            if p.is_file():
                files.append(str(p.relative_to(root)).replace("\\", "/"))

        content = "\n".join([
            f"# PROJECT_STATE — {root.name}",
            f"Generated: {datetime.now(timezone.utc).isoformat()}",
            "",
            "## Project",
            f"- Name: {root.name}",
            f"- Path: {root}",
            f"- Files: {len(files)}",
            "",
            "## AI Provider",
            f"- Mode: {prov.label}",
            f"- Detail: {prov.detail}",
            f"- API configured: {prov.api_configured}",
            "",
            "## Rojo",
            f"- Installed: {rojo.installed}",
            f"- Path: {rojo.path or 'n/d'}",
            f"- Version: {rojo.version or 'n/d'}",
            f"- Serving: {self.rojo.is_serving()}",
            "",
            "## Resources (snapshot)",
            f"- Source: {snap.source}",
            f"- CPU %: {snap.cpu_percent}",
            f"- RAM %: {snap.ram_percent}",
            f"- Disk %: {snap.disk_percent}",
            "",
            "## File list",
            *[f"- {f}" for f in files[:500]],
            ("- … (truncated)" if len(files) > 500 else ""),
            "",
            "## Notes",
            "- This file never contains API keys or Roblox cookies.",
            "- FREE MODE: share this with Grok Web for context.",
        ])

        out = self.export_dir / f"{root.name}_PROJECT_STATE.md"
        out.write_text(content, encoding="utf-8")
        # Also copy next to project for convenience
        (root / "PROJECT_STATE.md").write_text(content, encoding="utf-8")
        log.info("Wrote PROJECT_STATE → %s", out)
        return out

    def write_error_report(
        self,
        title: str,
        errors: List[str],
        extra: Optional[Dict[str, Any]] = None,
    ) -> Path:
        root_name = self.pm.current_project.name if self.pm.current_project else "no_project"
        lines = [
            f"# ERROR_REPORT — {root_name}",
            f"Generated: {datetime.now(timezone.utc).isoformat()}",
            f"Title: {title}",
            "",
            "## Errors",
        ]
        if not errors:
            lines.append("- (none)")
        else:
            lines.extend(f"- {e}" for e in errors)
        if extra:
            lines.append("")
            lines.append("## Extra")
            lines.append("```json")
            lines.append(json.dumps(extra, indent=2, ensure_ascii=False))
            lines.append("```")
        lines.extend([
            "",
            "## Notes",
            "- No secrets included.",
            "- Attach this file when asking Grok Web for fixes (FREE MODE).",
        ])
        content = "\n".join(lines)
        out = self.export_dir / f"{root_name}_ERROR_REPORT.md"
        out.write_text(content, encoding="utf-8")
        if self.pm.current_project:
            (self.pm.current_project / "ERROR_REPORT.md").write_text(content, encoding="utf-8")
        log.info("Wrote ERROR_REPORT → %s", out)
        return out

    def write_project_context(self, notes: str = "") -> Path:
        root = self._require_project()
        prov = self.ai.status()
        content = "\n".join([
            f"# PROJECT_CONTEXT — {root.name}",
            f"Generated: {datetime.now(timezone.utc).isoformat()}",
            "",
            "## Goal",
            notes.strip() or "(añade aquí el objetivo del proyecto)",
            "",
            "## Active AI mode",
            prov.label,
            prov.detail,
            "",
            "## Structure hint",
            "- src/shared — ModuleScripts compartidos",
            "- src/server — Scripts de servidor",
            "- src/client — LocalScripts",
            "",
            "## FREE MODE workflow",
            "1. Exporta estado/contexto desde GSL",
            "2. Compártelo con Grok Web",
            "3. Importa AI_TASK.json o ZIP generado",
            "4. Revisa y aprueba en AI Command Center",
            "",
            "## Security",
            "- Do not put API keys in this file.",
        ])
        out = self.export_dir / f"{root.name}_PROJECT_CONTEXT.md"
        out.write_text(content, encoding="utf-8")
        (root / "PROJECT_CONTEXT.md").write_text(content, encoding="utf-8")
        return out

    def export_source_package(self) -> Path:
        """Zip project sources (safe extensions only). No .env, no keys."""
        root = self._require_project()
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        out = self.export_dir / f"{root.name}_SOURCE_{stamp}.zip"

        with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for path in root.rglob("*"):
                if not path.is_file():
                    continue
                rel = path.relative_to(root)
                rel_s = str(rel).replace("\\", "/")
                # Skip secrets / junk
                if any(part.startswith(".") and part not in (".gitignore",) for part in rel.parts):
                    if path.suffix.lower() not in _SOURCE_EXTENSIONS and path.name not in (
                        "default.project.json", "README.md", "PROJECT_STATE.md",
                        "PROJECT_CONTEXT.md", "ERROR_REPORT.md",
                    ):
                        continue
                name_lower = path.name.lower()
                if name_lower in (".env", ".env.local", "credentials.json", "secrets.json"):
                    continue
                if path.suffix.lower() not in _SOURCE_EXTENSIONS and path.name not in (
                    "default.project.json", "README.md", "PROJECT_STATE.md",
                    "PROJECT_CONTEXT.md", "ERROR_REPORT.md", ".gitignore",
                ):
                    continue
                zf.write(path, arcname=f"{root.name}/{rel_s}")

        log.info("SOURCE_PACKAGE → %s", out)
        return out

    def export_all_free_mode(self, context_notes: str = "") -> Dict[str, str]:
        paths = {
            "state": str(self.write_project_state()),
            "context": str(self.write_project_context(context_notes)),
            "package": str(self.export_source_package()),
        }
        # empty error report template if none
        err = self.export_dir / f"{self.pm.current_project.name}_ERROR_REPORT.md"
        if not err.exists():
            paths["errors"] = str(self.write_error_report("template", []))
        else:
            paths["errors"] = str(err)
        return paths
