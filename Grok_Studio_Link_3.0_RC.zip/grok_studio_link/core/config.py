"""
Application configuration — paths, limits and preferences.
All sensitive values stay in environment / local config, never hardcoded secrets.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any


def _default_root() -> Path:
    return Path(__file__).resolve().parent.parent


@dataclass
class AppConfig:
    app_name: str = "GROK STUDIO LINK"
    version: str = "1.0.0"

    # Paths (relative to project root unless absolute)
    root_dir: Path = field(default_factory=_default_root)
    workspace_dir: Path = field(default_factory=lambda: _default_root() / "workspace")
    tasks_inbox: Path = field(default_factory=lambda: _default_root() / "tasks" / "inbox")
    tasks_completed: Path = field(default_factory=lambda: _default_root() / "tasks" / "completed")
    backups_dir: Path = field(default_factory=lambda: _default_root() / "backups")
    logs_dir: Path = field(default_factory=lambda: _default_root() / "logs")
    config_file: Path = field(default_factory=lambda: _default_root() / "config.json")

    # Security limits
    max_task_bytes: int = 2 * 1024 * 1024          # 2 MB
    max_file_content_bytes: int = 1 * 1024 * 1024  # 1 MB per file
    allowed_extensions: tuple[str, ...] = (
        ".lua", ".luau", ".json", ".txt", ".md", ".toml", ".yaml", ".yml"
    )

    # UI
    theme: str = "dark"
    window_width: int = 1280
    window_height: int = 800

    # MCP (placeholder for 2.0)
    mcp_enabled: bool = False
    mcp_command: str = ""
    mcp_args: list[str] = field(default_factory=list)

    def ensure_directories(self) -> None:
        for d in (
            self.workspace_dir,
            self.tasks_inbox,
            self.tasks_completed,
            self.backups_dir,
            self.logs_dir,
        ):
            d.mkdir(parents=True, exist_ok=True)

    def save(self) -> None:
        data = asdict(self)
        # Convert Paths to strings for JSON
        for key, value in data.items():
            if isinstance(value, Path):
                data[key] = str(value)
        self.config_file.write_text(json.dumps(data, indent=2), encoding="utf-8")

    @classmethod
    def load(cls) -> "AppConfig":
        cfg = cls()
        if cfg.config_file.exists():
            try:
                raw: dict[str, Any] = json.loads(cfg.config_file.read_text(encoding="utf-8"))
                for key, value in raw.items():
                    if hasattr(cfg, key):
                        current = getattr(cfg, key)
                        if isinstance(current, Path):
                            setattr(cfg, key, Path(value))
                        else:
                            setattr(cfg, key, value)
            except Exception:
                # Keep defaults on corrupt config
                pass
        cfg.ensure_directories()
        return cfg
