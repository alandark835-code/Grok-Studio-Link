"""
Project Manager — open, list and navigate Roblox projects inside the workspace.
"""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

from core.logger import get_logger
from core.security import SecurityManager, SecurityError

log = get_logger()


class ProjectManager:
    def __init__(self, workspace: Path, security: SecurityManager):
        self.workspace = workspace.resolve()
        self.security = security
        self.current_project: Optional[Path] = None

    def list_projects(self) -> List[Path]:
        if not self.workspace.exists():
            return []
        return sorted(
            [p for p in self.workspace.iterdir() if p.is_dir() and not p.name.startswith(".")],
            key=lambda p: p.name.lower(),
        )

    def open_project(self, name: str) -> Path:
        path = self.workspace / name
        if not path.exists() or not path.is_dir():
            raise FileNotFoundError(f"Project not found: {name}")
        self.current_project = path.resolve()
        log.info("Opened project: %s", self.current_project)
        return self.current_project

    def create_project(self, name: str) -> Path:
        # Basic sanitization
        safe_name = "".join(c for c in name if c.isalnum() or c in ("-", "_", " ")).strip()
        if not safe_name:
            raise ValueError("Invalid project name")
        path = self.workspace / safe_name
        if path.exists():
            raise FileExistsError(f"Project already exists: {safe_name}")
        path.mkdir(parents=True)
        # Minimal Roblox-like starter structure
        (path / "src").mkdir()
        (path / "src" / "shared").mkdir()
        (path / "src" / "server").mkdir()
        (path / "src" / "client").mkdir()
        log.info("Created project: %s", path)
        self.current_project = path
        return path

    def list_files(self, relative: str = "") -> List[Path]:
        if not self.current_project:
            return []
        base = self.current_project / relative if relative else self.current_project
        if not base.exists():
            return []
        return sorted(base.rglob("*"), key=lambda p: (not p.is_dir(), str(p).lower()))

    def read_file(self, relative_path: str) -> str:
        if not self.current_project:
            raise RuntimeError("No project open")
        # Security resolves against workspace, so we build a path relative to workspace
        rel_to_workspace = str(Path(self.current_project.name) / relative_path)
        full = self.security.resolve_safe(rel_to_workspace)
        if not full.is_file():
            raise FileNotFoundError(relative_path)
        return full.read_text(encoding="utf-8")

    def write_file(self, relative_path: str, content: str, overwrite: bool = False) -> Path:
        if not self.current_project:
            raise RuntimeError("No project open")
        rel_to_workspace = str(Path(self.current_project.name) / relative_path)
        full = self.security.resolve_safe(rel_to_workspace)

        if full.exists() and not overwrite:
            raise FileExistsError(f"File exists and overwrite=false: {relative_path}")

        self.security.check_content_size(content)
        if not self.security.is_allowed_extension(full):
            raise SecurityError(f"Extension not allowed: {full.suffix}")

        full.parent.mkdir(parents=True, exist_ok=True)
        full.write_text(content, encoding="utf-8")
        log.info("Wrote file: %s", full)
        return full

    def create_dir(self, relative_path: str) -> Path:
        if not self.current_project:
            raise RuntimeError("No project open")
        rel_to_workspace = str(Path(self.current_project.name) / relative_path)
        full = self.security.resolve_safe(rel_to_workspace)
        full.mkdir(parents=True, exist_ok=True)
        log.info("Created directory: %s", full)
        return full
