"""
Rojo Manager — detect installation, version, and run basic build/serve.
Does not invent CLI flags; uses well-known rojo commands.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional

from core.logger import get_logger

log = get_logger()


@dataclass
class RojoStatus:
    installed: bool = False
    path: str = ""
    version: str = ""
    message: str = "Rojo no detectado"
    last_log: str = ""


@dataclass
class RojoCommandResult:
    ok: bool
    command: List[str] = field(default_factory=list)
    returncode: int = -1
    stdout: str = ""
    stderr: str = ""


class RojoManager:
    def __init__(self, preferred_path: Optional[str] = None):
        self.preferred_path = preferred_path
        self._proc: Optional[subprocess.Popen] = None

    def detect(self) -> RojoStatus:
        path = self.preferred_path or shutil.which("rojo")
        if not path:
            return RojoStatus(
                installed=False,
                message=(
                    "Rojo no está en el PATH. Instálalo desde "
                    "https://github.com/rojo-rbx/rojo/releases o con "
                    "`cargo install rojo` / Aftman / Rokit."
                ),
            )
        version = self._run_version(path)
        return RojoStatus(
            installed=True,
            path=path,
            version=version or "(versión desconocida)",
            message=f"Rojo encontrado: {path}",
        )

    def _run_version(self, path: str) -> str:
        try:
            r = subprocess.run(
                [path, "--version"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            out = (r.stdout or r.stderr or "").strip()
            return out.splitlines()[0] if out else ""
        except Exception as e:
            log.warning("rojo --version failed: %s", e)
            return ""

    def init_default_project_json(self, project_dir: Path, name: str = "Project") -> Path:
        """
        Create a minimal default.project.json if missing.
        Structure matches common Rojo layouts (src → game tree).
        """
        project_dir.mkdir(parents=True, exist_ok=True)
        target = project_dir / "default.project.json"
        if target.exists():
            return target

        data = {
            "name": name,
            "tree": {
                "$className": "DataModel",
                "ReplicatedStorage": {
                    "$className": "ReplicatedStorage",
                    "Shared": {"$path": "src/shared"},
                },
                "ServerScriptService": {
                    "$className": "ServerScriptService",
                    "Server": {"$path": "src/server"},
                },
                "StarterPlayer": {
                    "$className": "StarterPlayer",
                    "StarterPlayerScripts": {
                        "$className": "StarterPlayerScripts",
                        "Client": {"$path": "src/client"},
                    },
                },
            },
        }
        target.write_text(json.dumps(data, indent=2), encoding="utf-8")
        # Ensure folders exist
        for sub in ("src/shared", "src/server", "src/client"):
            (project_dir / sub).mkdir(parents=True, exist_ok=True)
        log.info("Created %s", target)
        return target

    def build(self, project_dir: Path, output: Optional[Path] = None) -> RojoCommandResult:
        status = self.detect()
        if not status.installed:
            return RojoCommandResult(ok=False, stderr=status.message)

        cmd = [status.path, "build"]
        project_file = project_dir / "default.project.json"
        if project_file.exists():
            cmd.append(str(project_file))
        else:
            cmd.append(str(project_dir))
        if output:
            cmd.extend(["--output", str(output)])

        return self._run(cmd, cwd=project_dir)

    def serve(self, project_dir: Path, port: int = 34872) -> RojoCommandResult:
        """
        Start `rojo serve` as a background process.
        Only one serve at a time in Alpha 0.1.
        """
        status = self.detect()
        if not status.installed:
            return RojoCommandResult(ok=False, stderr=status.message)

        if self._proc and self._proc.poll() is None:
            return RojoCommandResult(
                ok=False,
                stderr="Ya hay un proceso rojo serve en ejecución. Deténlo primero.",
            )

        project_file = project_dir / "default.project.json"
        cmd = [status.path, "serve"]
        if project_file.exists():
            cmd.append(str(project_file))
        else:
            cmd.append(str(project_dir))
        cmd.extend(["--port", str(port)])

        try:
            self._proc = subprocess.Popen(
                cmd,
                cwd=str(project_dir),
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            log.info("rojo serve started pid=%s", self._proc.pid)
            return RojoCommandResult(
                ok=True,
                command=cmd,
                returncode=0,
                stdout=f"rojo serve iniciado (pid {self._proc.pid}) en puerto {port}",
            )
        except Exception as e:
            return RojoCommandResult(ok=False, command=cmd, stderr=str(e))

    def stop_serve(self) -> RojoCommandResult:
        if not self._proc or self._proc.poll() is not None:
            return RojoCommandResult(ok=True, stdout="No había proceso serve activo.")
        try:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._proc.kill()
            pid = self._proc.pid
            self._proc = None
            return RojoCommandResult(ok=True, stdout=f"Proceso serve (pid {pid}) detenido.")
        except Exception as e:
            return RojoCommandResult(ok=False, stderr=str(e))

    def is_serving(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def _run(self, cmd: List[str], cwd: Path) -> RojoCommandResult:
        try:
            r = subprocess.run(
                cmd,
                cwd=str(cwd),
                capture_output=True,
                text=True,
                timeout=120,
            )
            return RojoCommandResult(
                ok=r.returncode == 0,
                command=cmd,
                returncode=r.returncode,
                stdout=r.stdout or "",
                stderr=r.stderr or "",
            )
        except subprocess.TimeoutExpired:
            return RojoCommandResult(ok=False, command=cmd, stderr="Timeout (120s)")
        except Exception as e:
            return RojoCommandResult(ok=False, command=cmd, stderr=str(e))
