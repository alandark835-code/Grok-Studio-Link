"""
Task Engine — validates and applies JSON task documents from Grok.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.logger import get_logger
from core.security import SecurityManager, SecurityError
from core.project_manager import ProjectManager
from core.backup_manager import BackupManager

log = get_logger()


@dataclass
class OperationResult:
    action: str
    path: str
    success: bool
    message: str


@dataclass
class TaskReport:
    project: str
    summary: str
    success: bool
    operations: List[OperationResult] = field(default_factory=list)
    backup_path: Optional[str] = None
    errors: List[str] = field(default_factory=list)


class TaskEngine:
    """Parses, validates and applies GSL task JSON documents."""

    def __init__(
        self,
        project_manager: ProjectManager,
        security: SecurityManager,
        backup_manager: BackupManager,
    ):
        self.pm = project_manager
        self.security = security
        self.backups = backup_manager

    def load_task(self, source: Path | str | bytes | dict) -> dict:
        """Load and parse a task from file path, raw JSON string/bytes, or dict."""
        if isinstance(source, dict):
            data = source
        elif isinstance(source, (bytes, bytearray)):
            self.security.check_task_size(source)
            data = json.loads(source.decode("utf-8"))
        elif isinstance(source, Path):
            raw = source.read_bytes()
            self.security.check_task_size(raw)
            data = json.loads(raw.decode("utf-8"))
        elif isinstance(source, str):
            raw = source.encode("utf-8")
            self.security.check_task_size(raw)
            data = json.loads(source)
        else:
            raise TypeError("Unsupported task source type")

        self._validate_schema(data)
        return data

    def _validate_schema(self, data: dict) -> None:
        if not isinstance(data, dict):
            raise ValueError("Task must be a JSON object")

        if data.get("schema_version") != 1:
            raise ValueError("Unsupported schema_version (expected 1)")

        if not data.get("project") or not isinstance(data["project"], str):
            raise ValueError("Missing or invalid 'project' field")

        if "operations" not in data or not isinstance(data["operations"], list):
            raise ValueError("Missing or invalid 'operations' array")

        if len(data["operations"]) == 0:
            raise ValueError("Task has no operations")

        for i, op in enumerate(data["operations"]):
            if not isinstance(op, dict):
                raise ValueError(f"Operation[{i}] must be an object")
            action = op.get("action")
            if not action:
                raise ValueError(f"Operation[{i}] missing 'action'")
            self.security.validate_action(action)
            if "path" not in op or not isinstance(op["path"], str):
                raise ValueError(f"Operation[{i}] missing valid 'path'")
            if action == "write_file":
                if "content" not in op or not isinstance(op["content"], str):
                    raise ValueError(f"Operation[{i}] write_file requires string 'content'")
                self.security.check_content_size(op["content"])

    def preview(self, task: dict) -> List[str]:
        """Return human-readable preview lines of what would happen."""
        lines = [
            f"Proyecto : {task.get('project')}",
            f"Resumen  : {task.get('summary', '(sin resumen)')}",
            f"Operaciones ({len(task['operations'])}):",
        ]
        for i, op in enumerate(task["operations"], 1):
            overwrite = op.get("overwrite", False)
            lines.append(
                f"  {i}. [{op['action']}] {op['path']}"
                + (" (overwrite)" if overwrite else "")
            )
        return lines

    def apply(self, task: dict, create_backup: bool = True) -> TaskReport:
        """Apply all operations. Creates a backup of the current project first."""
        project_name = task["project"]
        report = TaskReport(
            project=project_name,
            summary=task.get("summary", ""),
            success=True,
        )

        # Ensure project is open / exists
        try:
            if not self.pm.current_project or self.pm.current_project.name != project_name:
                # Try open existing, otherwise create
                projects = {p.name: p for p in self.pm.list_projects()}
                if project_name in projects:
                    self.pm.open_project(project_name)
                else:
                    self.pm.create_project(project_name)
        except Exception as e:
            report.success = False
            report.errors.append(f"No se pudo abrir/crear el proyecto: {e}")
            return report

        # Backup
        if create_backup and self.pm.current_project:
            try:
                backup = self.backups.create_backup(
                    self.pm.current_project,
                    label=task.get("summary", "task")[:30],
                )
                report.backup_path = str(backup)
            except Exception as e:
                report.errors.append(f"Backup falló: {e}")
                # Continue? Safer to abort
                report.success = False
                return report

        # Apply operations
        for op in task["operations"]:
            action = op["action"]
            path = op["path"]
            try:
                if action == "create_dir":
                    self.pm.create_dir(path)
                    report.operations.append(
                        OperationResult(action, path, True, "Directorio creado")
                    )
                elif action == "write_file":
                    overwrite = bool(op.get("overwrite", False))
                    self.pm.write_file(path, op["content"], overwrite=overwrite)
                    report.operations.append(
                        OperationResult(action, path, True, "Archivo escrito")
                    )
                else:
                    # Should have been caught by validate_action
                    raise SecurityError(f"Acción no permitida: {action}")
            except Exception as e:
                report.success = False
                msg = str(e)
                report.operations.append(OperationResult(action, path, False, msg))
                report.errors.append(f"{action} {path}: {msg}")
                log.error("Operation failed: %s %s → %s", action, path, e)

        return report
