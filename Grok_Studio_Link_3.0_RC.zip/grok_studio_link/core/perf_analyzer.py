"""
Static performance hints for Luau scripts (not runtime profiling).
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List


@dataclass
class PerfHint:
    severity: str
    file: str
    line: int
    message: str


@dataclass
class PerfReport:
    files_scanned: int = 0
    hints: List[PerfHint] = field(default_factory=list)


class PerformanceAnalyzer:
    RULES = [
        ("HIGH", re.compile(r"while\s+true\s+do"), "while true sin ver task.wait — riesgo de lag/crash"),
        ("HIGH", re.compile(r"for\s+.*\s+in\s+pairs\s*\([^)]+\)\s+do[\s\S]{0,200}:GetChildren\s*\("), "GetChildren dentro de bucle — cachea resultados si es posible"),
        ("MEDIUM", re.compile(r"\.Touched\s*:"), "Touched puede dispararse muy seguido — debounce recomendado"),
        ("MEDIUM", re.compile(r"RenderStepped|Heartbeat|Stepped"), "Conexión por frame — desconéctala cuando no haga falta"),
        ("MEDIUM", re.compile(r"Instance\.new\s*\(\s*[\"']Part[\"']"), "Creación de Parts — considera pooling o menos instancias"),
        ("LOW", re.compile(r"string\.concatenate|\.\."), "Concatenación frecuente en bucle puede ser costosa"),
        ("INFO", re.compile(r"task\.wait\s*\(\s*0\s*\)"), "task.wait(0) cede un frame — úsalo con intención"),
    ]

    def analyze_tree(self, root: Path) -> PerfReport:
        report = PerfReport()
        if not root.exists():
            return report
        for path in sorted(root.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in (".lua", ".luau"):
                continue
            report.files_scanned += 1
            rel = str(path.relative_to(root)).replace("\\", "/")
            try:
                lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            except Exception:
                continue
            for i, line in enumerate(lines, 1):
                if line.strip().startswith("--"):
                    continue
                for severity, rx, msg in self.RULES:
                    if rx.search(line):
                        report.hints.append(PerfHint(severity, rel, i, msg))
        return report
