"""
AI Provider Manager — FREE MODE (default) + optional API MODE.
LOCAL AI is reserved for a later phase.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.logger import get_logger

log = get_logger()


class ProviderMode(str, Enum):
    FREE = "free"          # Grok Web + file exchange
    API = "api"            # Optional remote API
    LOCAL = "local"        # Future: Ollama / llama.cpp
    AUTO = "auto"          # Future: pick under user policy


@dataclass
class ProviderStatus:
    mode: ProviderMode = ProviderMode.FREE
    label: str = "FREE MODE"
    detail: str = "Grok Web gratuito + intercambio de archivos (ZIP/JSON). Sin API Key."
    api_configured: bool = False
    api_endpoint: str = ""
    api_model: str = ""
    can_call_api: bool = False
    last_error: str = ""


@dataclass
class APIConfig:
    """Stored separately; never written into project exports."""
    endpoint: str = "https://api.x.ai/v1"
    model: str = ""
    # Key is NOT stored in this dataclass when serializing to project files.
    # Alpha 0.1 keeps key only in memory / optional local config outside workspace.
    timeout_seconds: int = 60
    max_tokens: int = 4096


class AIProviderManager:
    """
    Central switch for AI modality.
    FREE MODE always works without a key.
    API MODE is optional and disabled until configured.
    """

    def __init__(self, config_path: Optional[Path] = None):
        self.config_path = config_path
        self._mode = ProviderMode.FREE
        self._api = APIConfig()
        self._api_key: Optional[str] = None  # memory only in Alpha 0.1
        self._last_error = ""
        if config_path and config_path.exists():
            self._load_safe_config(config_path)

    # ---- public API -----------------------------------------------------

    def status(self) -> ProviderStatus:
        if self._mode == ProviderMode.FREE:
            return ProviderStatus(
                mode=ProviderMode.FREE,
                label="FREE MODE",
                detail="Grok Web gratuito + ZIP/JSON. No se requiere API Key.",
                api_configured=bool(self._api_key),
            )
        if self._mode == ProviderMode.API:
            ok = bool(self._api_key and self._api.endpoint)
            return ProviderStatus(
                mode=ProviderMode.API,
                label="API MODE",
                detail=(
                    f"Endpoint: {self._api.endpoint} | Modelo: {self._api.model or '(sin definir)'}"
                    if ok
                    else "API MODE seleccionado pero falta API Key o endpoint."
                ),
                api_configured=ok,
                api_endpoint=self._api.endpoint,
                api_model=self._api.model,
                can_call_api=ok,
                last_error=self._last_error,
            )
        if self._mode == ProviderMode.LOCAL:
            return ProviderStatus(
                mode=ProviderMode.LOCAL,
                label="LOCAL AI MODE",
                detail="Reservado para una fase posterior (Ollama / llama.cpp).",
                last_error="LOCAL AI aún no implementado en Alpha 0.1",
            )
        return ProviderStatus(
            mode=ProviderMode.AUTO,
            label="AUTO SELECT",
            detail="Reservado. Por ahora equivale a FREE MODE.",
        )

    def set_mode(self, mode: ProviderMode) -> ProviderStatus:
        if mode == ProviderMode.LOCAL:
            self._last_error = "LOCAL AI MODE llegará en una fase posterior."
            log.info("LOCAL mode requested — not available yet")
            # Stay on previous mode
            return self.status()
        self._mode = mode
        self._last_error = ""
        log.info("AI provider mode → %s", mode.value)
        return self.status()

    def configure_api(
        self,
        endpoint: str = "",
        model: str = "",
        api_key: Optional[str] = None,
    ) -> ProviderStatus:
        if endpoint:
            self._api.endpoint = endpoint.strip().rstrip("/")
        if model:
            self._api.model = model.strip()
        if api_key is not None:
            key = api_key.strip()
            self._api_key = key if key else None
        self._last_error = ""
        self._save_safe_config()
        return self.status()

    def clear_api_key(self) -> ProviderStatus:
        self._api_key = None
        self._last_error = ""
        log.info("API key cleared from memory")
        return self.status()

    def export_free_mode_bundle_paths(self) -> Dict[str, str]:
        """Document which artifact names FREE MODE uses."""
        return {
            "task": "AI_TASK.json",
            "context": "PROJECT_CONTEXT.md",
            "state": "PROJECT_STATE.md",
            "errors": "ERROR_REPORT.md",
            "package": "SOURCE_PACKAGE.zip",
        }

    def try_api_ping(self) -> Dict[str, Any]:
        """Validate config and optionally perform a minimal HTTP chat call."""
        if not self._api_key:
            self._last_error = "No hay API Key en memoria."
            return {"ok": False, "message": self._last_error, "network_call": False}
        if not self._api.endpoint:
            self._last_error = "Falta endpoint."
            return {"ok": False, "message": self._last_error, "network_call": False}
        if not self._api.model:
            self._last_error = "Falta modelo (obligatorio para la prueba HTTP)."
            return {
                "ok": False,
                "message": self._last_error,
                "network_call": False,
                "endpoint": self._api.endpoint,
            }
        try:
            from core.api_client import APIClient, APIClientError
            client = APIClient(self._api.endpoint, self._api_key, self._api.model)
            data = client.chat(
                "Responde exactamente: pong",
                system="Eres un chequeo de conectividad. Responde solo: pong",
            )
            self._last_error = ""
            # Avoid dumping full response secrets; keep short summary
            summary = str(data)[:400]
            return {
                "ok": True,
                "message": f"HTTP OK — respuesta recibida.\n{summary}",
                "network_call": True,
                "endpoint": self._api.endpoint,
                "model": self._api.model,
            }
        except Exception as e:
            self._last_error = str(e)
            return {
                "ok": False,
                "message": f"Fallo HTTP: {e}",
                "network_call": True,
                "endpoint": self._api.endpoint,
                "model": self._api.model,
            }

    # ---- persistence (never write secrets into workspace projects) ------

    def _load_safe_config(self, path: Path) -> None:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            mode = data.get("mode", "free")
            try:
                self._mode = ProviderMode(mode)
            except ValueError:
                self._mode = ProviderMode.FREE
            api = data.get("api") or {}
            self._api.endpoint = api.get("endpoint") or self._api.endpoint
            self._api.model = api.get("model") or ""
            # Key intentionally not loaded from plain JSON in Alpha 0.1
        except Exception as e:
            log.warning("Could not load provider config: %s", e)

    def _save_safe_config(self) -> None:
        if not self.config_path:
            return
        try:
            self.config_path.parent.mkdir(parents=True, exist_ok=True)
            payload = {
                "mode": self._mode.value,
                "api": {
                    "endpoint": self._api.endpoint,
                    "model": self._api.model,
                    # no api_key field on purpose
                },
            }
            self.config_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        except Exception as e:
            log.warning("Could not save provider config: %s", e)
