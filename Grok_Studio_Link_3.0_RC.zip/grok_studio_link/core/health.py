"""Runtime dependency health checks."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Tuple


@dataclass
class HealthReport:
    ok: bool
    lines: List[str] = field(default_factory=list)


def check_health() -> HealthReport:
    lines: List[str] = []
    required_ok = True

    def check(mod: str, required: bool = True) -> None:
        nonlocal required_ok
        try:
            __import__(mod)
            lines.append(f"OK  {mod}")
        except Exception as e:
            mark = "ERR" if required else "—"
            lines.append(f"{mark}  {mod}: {e}")
            if required:
                required_ok = False

    check("PySide6", True)
    check("httpx", False)
    check("psutil", False)
    check("anyio", False)
    check("mcp", False)
    check("pathvalidate", False)

    lines.append("")
    lines.append("mcp es opcional: sin él funciona todo excepto MCP Studio.")
    lines.append("httpx es opcional: sin él no hay prueba HTTP de API MODE.")
    return HealthReport(ok=required_ok, lines=lines)
