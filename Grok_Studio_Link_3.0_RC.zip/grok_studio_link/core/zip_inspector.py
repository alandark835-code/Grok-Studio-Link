"""
ZIP Package Inspector — safe inspection and optional extract into workspace.
Blocks path traversal, absolute paths, zip bombs (basic limits).
Does not execute code from the archive.
"""

from __future__ import annotations

import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Set

from core.logger import get_logger
from core.security import SecurityManager, SecurityError

log = get_logger()

MAX_MEMBERS = 5000
MAX_UNCOMPRESSED_TOTAL = 200 * 1024 * 1024  # 200 MB
MAX_SINGLE_FILE = 50 * 1024 * 1024


@dataclass
class ZipMemberInfo:
    name: str
    file_size: int
    compress_size: int
    is_dir: bool


@dataclass
class ZipInspection:
    path: str
    ok: bool
    members: List[ZipMemberInfo] = field(default_factory=list)
    scripts: List[str] = field(default_factory=list)
    json_files: List[str] = field(default_factory=list)
    has_default_project: bool = False
    warnings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)


class ZipInspector:
    def __init__(self, security: SecurityManager):
        self.security = security

    def inspect(self, zip_path: Path) -> ZipInspection:
        result = ZipInspection(path=str(zip_path), ok=False)
        if not zip_path.is_file():
            result.errors.append("El archivo no existe")
            return result
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                infos = zf.infolist()
                if len(infos) > MAX_MEMBERS:
                    result.errors.append(f"Demasiados miembros ({len(infos)} > {MAX_MEMBERS})")
                    return result

                total_uncomp = 0
                for info in infos:
                    name = info.filename.replace("\\", "/")
                    if name.startswith("/") or name.startswith("../") or "/../" in f"/{name}/":
                        result.errors.append(f"Ruta insegura: {name}")
                        continue
                    if ":" in name.split("/")[0]:  # Windows absolute-ish
                        result.errors.append(f"Ruta absoluta rechazada: {name}")
                        continue
                    total_uncomp += max(info.file_size, 0)
                    if info.file_size > MAX_SINGLE_FILE:
                        result.warnings.append(f"Archivo grande: {name} ({info.file_size} bytes)")
                    member = ZipMemberInfo(
                        name=name,
                        file_size=info.file_size,
                        compress_size=info.compress_size,
                        is_dir=name.endswith("/"),
                    )
                    result.members.append(member)
                    lower = name.lower()
                    if lower.endswith((".lua", ".luau")):
                        result.scripts.append(name)
                    if lower.endswith(".json"):
                        result.json_files.append(name)
                    if lower.endswith("default.project.json") or lower == "default.project.json":
                        result.has_default_project = True

                if total_uncomp > MAX_UNCOMPRESSED_TOTAL:
                    result.errors.append(
                        f"Tamaño descomprimido excesivo ({total_uncomp} bytes) — posible zip bomb"
                    )
                    return result

            result.ok = len(result.errors) == 0
            if not result.members:
                result.warnings.append("ZIP vacío o sin entradas válidas")
            return result
        except zipfile.BadZipFile:
            result.errors.append("ZIP corrupto o no válido")
            return result
        except Exception as e:
            result.errors.append(str(e))
            return result

    def extract_to_project(
        self,
        zip_path: Path,
        project_root: Path,
        *,
        overwrite: bool = False,
        allowed_suffixes: Optional[Set[str]] = None,
    ) -> List[str]:
        """
        Extract safe members under project_root.
        Returns list of written relative paths.
        """
        inspection = self.inspect(zip_path)
        if not inspection.ok:
            raise SecurityError("; ".join(inspection.errors) or "Inspección fallida")

        allowed = allowed_suffixes or {
            ".lua", ".luau", ".json", ".md", ".txt", ".toml", ".yaml", ".yml", ".gitignore",
        }
        written: List[str] = []

        with zipfile.ZipFile(zip_path, "r") as zf:
            for info in zf.infolist():
                name = info.filename.replace("\\", "/")
                if name.endswith("/") or not name.strip():
                    continue
                # strip a single top-level folder if all files share it
                parts = Path(name).parts
                rel = Path(*parts)
                # Prevent escape
                dest = (project_root / rel).resolve()
                try:
                    dest.relative_to(project_root.resolve())
                except ValueError:
                    log.warning("Skip escape path %s", name)
                    continue
                if dest.suffix.lower() not in allowed and dest.name != "default.project.json":
                    log.info("Skip disallowed suffix: %s", name)
                    continue
                if dest.exists() and not overwrite:
                    log.info("Skip existing (no overwrite): %s", dest)
                    continue
                dest.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(info) as src, open(dest, "wb") as out:
                    data = src.read(MAX_SINGLE_FILE + 1)
                    if len(data) > MAX_SINGLE_FILE:
                        raise SecurityError(f"Archivo demasiado grande al extraer: {name}")
                    out.write(data)
                written.append(str(rel).replace("\\", "/"))
                log.info("Extracted %s", dest)
        return written
