"""
Simple structured logger for GSL.
Writes both to console and to a rotating-style daily log file.
"""

from __future__ import annotations

import logging
import sys
from datetime import datetime
from pathlib import Path

_LOG = logging.getLogger("gsl")


def setup_logger(logs_dir: Path | None = None, level: int = logging.INFO) -> logging.Logger:
    if logs_dir is None:
        logs_dir = Path(__file__).resolve().parent.parent / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    log_file = logs_dir / f"gsl_{datetime.now():%Y%m%d}.log"

    _LOG.setLevel(level)
    _LOG.handlers.clear()

    fmt = logging.Formatter(
        "[%(asctime)s] %(levelname)-7s %(name)s — %(message)s",
        datefmt="%H:%M:%S",
    )

    # Console
    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(fmt)
    _LOG.addHandler(ch)

    # File
    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setFormatter(fmt)
    _LOG.addHandler(fh)

    _LOG.info("Logger ready → %s", log_file)
    return _LOG


def get_logger() -> logging.Logger:
    return _LOG
