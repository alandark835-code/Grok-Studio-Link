"""
Backup Manager — creates timestamped copies before destructive-ish operations.
"""

from __future__ import annotations

import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Optional

from core.logger import get_logger

log = get_logger()


class BackupManager:
    def __init__(self, backups_root: Path):
        self.backups_root = backups_root
        self.backups_root.mkdir(parents=True, exist_ok=True)

    def create_backup(self, project_path: Path, label: str = "auto") -> Path:
        if not project_path.exists():
            raise FileNotFoundError(project_path)

        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_label = "".join(c if c.isalnum() or c in "-_" else "_" for c in label)[:40]
        backup_name = f"{project_path.name}_{stamp}_{safe_label}"
        dest = self.backups_root / backup_name

        shutil.copytree(project_path, dest, dirs_exist_ok=False)
        log.info("Backup created: %s", dest)
        return dest

    def list_backups(self, project_name: Optional[str] = None) -> List[Path]:
        items = sorted(self.backups_root.iterdir(), reverse=True)
        if project_name:
            items = [p for p in items if p.name.startswith(project_name)]
        return [p for p in items if p.is_dir()]

    def restore_backup(self, backup_path: Path, target_project: Path) -> None:
        if not backup_path.exists():
            raise FileNotFoundError(backup_path)
        if target_project.exists():
            # Safety: rename current instead of deleting
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            safety = target_project.parent / f"{target_project.name}_before_restore_{stamp}"
            target_project.rename(safety)
            log.warning("Existing project moved to %s", safety)
        shutil.copytree(backup_path, target_project)
        log.info("Restored backup %s → %s", backup_path, target_project)
