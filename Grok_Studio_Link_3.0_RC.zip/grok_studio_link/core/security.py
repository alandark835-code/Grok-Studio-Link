"""
Security Manager — path sandboxing, size limits, dangerous operation gates.
"""

from __future__ import annotations

import re
from pathlib import Path, PurePosixPath
from typing import Iterable

from core.logger import get_logger

log = get_logger()


class SecurityError(Exception):
    """Raised when a security policy is violated."""


class SecurityManager:
    def __init__(
        self,
        workspace_root: Path,
        max_task_bytes: int = 2 * 1024 * 1024,
        max_file_bytes: int = 1 * 1024 * 1024,
        allowed_extensions: Iterable[str] = (".lua", ".luau", ".json", ".txt", ".md"),
    ):
        self.workspace_root = workspace_root.resolve()
        self.max_task_bytes = max_task_bytes
        self.max_file_bytes = max_file_bytes
        self.allowed_extensions = {ext.lower() for ext in allowed_extensions}

    # ------------------------------------------------------------------
    # Path safety
    # ------------------------------------------------------------------

    def resolve_safe(self, relative_path: str) -> Path:
        """
        Resolve a relative path inside the workspace.
        Rejects absolute paths, .. traversal and null bytes.
        """
        if not relative_path or not isinstance(relative_path, str):
            raise SecurityError("Empty or invalid path")

        if "\x00" in relative_path:
            raise SecurityError("Null byte in path")

        # Normalize separators and reject absolute
        cleaned = relative_path.replace("\\", "/").lstrip("/")
        pure = PurePosixPath(cleaned)

        if pure.is_absolute():
            raise SecurityError(f"Absolute paths are forbidden: {relative_path}")

        if ".." in pure.parts:
            raise SecurityError(f"Path traversal detected: {relative_path}")

        full = (self.workspace_root / Path(*pure.parts)).resolve()

        try:
            full.relative_to(self.workspace_root)
        except ValueError:
            raise SecurityError(f"Path escapes workspace: {relative_path}")

        return full

    def is_allowed_extension(self, path: Path) -> bool:
        return path.suffix.lower() in self.allowed_extensions

    # ------------------------------------------------------------------
    # Content limits
    # ------------------------------------------------------------------

    def check_task_size(self, raw_bytes: bytes) -> None:
        if len(raw_bytes) > self.max_task_bytes:
            raise SecurityError(
                f"Task exceeds size limit ({len(raw_bytes)} > {self.max_task_bytes} bytes)"
            )

    def check_content_size(self, content: str) -> None:
        size = len(content.encode("utf-8"))
        if size > self.max_file_bytes:
            raise SecurityError(
                f"File content exceeds size limit ({size} > {self.max_file_bytes} bytes)"
            )

    # ------------------------------------------------------------------
    # Operation policy (v1.0)
    # ------------------------------------------------------------------

    ALLOWED_ACTIONS = {"create_dir", "write_file"}

    def validate_action(self, action: str) -> None:
        if action not in self.ALLOWED_ACTIONS:
            raise SecurityError(
                f"Action '{action}' is not allowed in GSL 1.0. "
                f"Permitted: {sorted(self.ALLOWED_ACTIONS)}"
            )

    def require_confirmation(self, action: str, path: str) -> str:
        """Return a human-readable confirmation message."""
        return (
            f"¿Confirmas la operación?\n\n"
            f"Acción : {action}\n"
            f"Ruta   : {path}\n\n"
            f"Se creará un backup automático antes de aplicar cambios."
        )
