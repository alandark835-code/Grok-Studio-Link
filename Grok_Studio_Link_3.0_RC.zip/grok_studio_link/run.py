#!/usr/bin/env python3
"""
GROK STUDIO LINK 1.0
Entry point — Zero Cost local Roblox Studio bridge
"""

import sys
from pathlib import Path

# Ensure project root is on sys.path
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt
from app.main_window import MainWindow
from core.config import AppConfig
from core.logger import setup_logger


def main() -> int:
    setup_logger()
    config = AppConfig.load()

    # High-DPI support
    QApplication.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
    )

    app = QApplication(sys.argv)
    app.setApplicationName("GROK STUDIO LINK")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("Grok Programmer")

    window = MainWindow(config)
    window.show()

    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
