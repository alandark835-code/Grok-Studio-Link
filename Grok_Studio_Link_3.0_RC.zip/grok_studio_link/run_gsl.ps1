Set-Location $PSScriptRoot
if (-not (Test-Path ".venv\Scripts\python.exe")) {
  Write-Host "No hay .venv. Ejecuta .\install_deps.bat primero." -ForegroundColor Yellow
  exit 1
}
& .\.venv\Scripts\Activate.ps1
Write-Host "Iniciando GROK STUDIO LINK..." -ForegroundColor Cyan
python run.py
