"""
Resource Monitor UI — read-only metrics.
"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QGroupBox, QPlainTextEdit
)

from core.resource_monitor import ResourceMonitor


class ResourcePanel(QWidget):
    def __init__(self, monitor: ResourceMonitor, parent=None):
        super().__init__(parent)
        self.monitor = monitor
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        title = QLabel("Resource Monitor")
        title.setObjectName("title")
        layout.addWidget(title)

        sub = QLabel(
            "Solo lectura. No modifica prioridades ni cierra procesos. "
            "Instala psutil para más detalle: pip install psutil"
        )
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        box = QGroupBox("Instantánea del sistema")
        bl = QVBoxLayout(box)
        self.view = QPlainTextEdit()
        self.view.setReadOnly(True)
        bl.addWidget(self.view)
        btn = QPushButton("Actualizar métricas")
        btn.setObjectName("primary")
        btn.clicked.connect(self.refresh)
        bl.addWidget(btn)
        layout.addWidget(box)
        layout.addStretch()

    def refresh(self):
        snap = self.monitor.snapshot()
        lines = [
            f"Fuente     : {snap.source}",
            f"Plataforma : {snap.platform}",
            f"CPU %      : {snap.cpu_percent if snap.cpu_percent is not None else 'n/d'}",
            f"RAM total  : {snap.ram_total_gb if snap.ram_total_gb is not None else 'n/d'} GB",
            f"RAM usada  : {snap.ram_used_gb if snap.ram_used_gb is not None else 'n/d'} GB",
            f"RAM %      : {snap.ram_percent if snap.ram_percent is not None else 'n/d'}",
            f"Disco total: {snap.disk_total_gb if snap.disk_total_gb is not None else 'n/d'} GB",
            f"Disco usado: {snap.disk_used_gb if snap.disk_used_gb is not None else 'n/d'} GB",
            f"Disco %    : {snap.disk_percent if snap.disk_percent is not None else 'n/d'}",
            f"Procesos   : {snap.process_count if snap.process_count is not None else 'n/d'}",
            "",
            "Notas:",
        ]
        lines.extend(f"  • {n}" for n in snap.notes)
        self.view.setPlainText("\n".join(lines))
