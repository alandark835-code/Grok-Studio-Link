"""
Rojo Manager UI — detect, init project.json, build, serve.
"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QGroupBox, QPlainTextEdit, QMessageBox, QSpinBox
)

from core.rojo_manager import RojoManager
from core.project_manager import ProjectManager
from core.logger import get_logger

log = get_logger()


class RojoPanel(QWidget):
    def __init__(self, rojo: RojoManager, project_manager: ProjectManager, parent=None):
        super().__init__(parent)
        self.rojo = rojo
        self.pm = project_manager
        self._build_ui()
        self.refresh_detect()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("Rojo Manager")
        title.setObjectName("title")
        layout.addWidget(title)

        sub = QLabel(
            "Detecta Rojo en el PATH, genera default.project.json, "
            "ejecuta build y serve. MCP y Rojo son independientes."
        )
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        status_box = QGroupBox("Detección")
        s_layout = QVBoxLayout(status_box)
        self.status_label = QLabel("—")
        self.status_label.setWordWrap(True)
        s_layout.addWidget(self.status_label)
        btn_detect = QPushButton("Detectar Rojo")
        btn_detect.clicked.connect(self.refresh_detect)
        s_layout.addWidget(btn_detect)
        layout.addWidget(status_box)

        actions = QGroupBox("Acciones sobre el proyecto actual")
        a_layout = QVBoxLayout(actions)

        row1 = QHBoxLayout()
        btn_init = QPushButton("Crear default.project.json")
        btn_init.clicked.connect(self._init_project)
        row1.addWidget(btn_init)
        btn_build = QPushButton("Rojo Build")
        btn_build.setObjectName("primary")
        btn_build.clicked.connect(self._build)
        row1.addWidget(btn_build)
        a_layout.addLayout(row1)

        row2 = QHBoxLayout()
        row2.addWidget(QLabel("Puerto serve:"))
        self.port_spin = QSpinBox()
        self.port_spin.setRange(1024, 65535)
        self.port_spin.setValue(34872)
        row2.addWidget(self.port_spin)
        btn_serve = QPushButton("Rojo Serve")
        btn_serve.clicked.connect(self._serve)
        row2.addWidget(btn_serve)
        btn_stop = QPushButton("Detener Serve")
        btn_stop.clicked.connect(self._stop_serve)
        row2.addWidget(btn_stop)
        a_layout.addLayout(row2)
        layout.addWidget(actions)

        log_box = QGroupBox("Salida")
        l_layout = QVBoxLayout(log_box)
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        l_layout.addWidget(self.log_view)
        layout.addWidget(log_box)

    def refresh_detect(self):
        st = self.rojo.detect()
        if st.installed:
            self.status_label.setText(
                f"✅ Instalado\nRuta: {st.path}\nVersión: {st.version}\n{st.message}"
            )
        else:
            self.status_label.setText(f"❌ No detectado\n{st.message}")

    def _require_project(self) -> Path | None:
        if not self.pm.current_project:
            QMessageBox.warning(self, "Proyecto", "Abre o crea un proyecto primero.")
            return None
        return self.pm.current_project

    def _init_project(self):
        root = self._require_project()
        if not root:
            return
        path = self.rojo.init_default_project_json(root, name=root.name)
        self.log_view.appendPlainText(f"Creado/existe: {path}")
        QMessageBox.information(self, "Rojo", f"default.project.json listo en:\n{path}")

    def _build(self):
        root = self._require_project()
        if not root:
            return
        if not (root / "default.project.json").exists():
            self.rojo.init_default_project_json(root, name=root.name)
        result = self.rojo.build(root)
        self._show_result(result)

    def _serve(self):
        root = self._require_project()
        if not root:
            return
        if not (root / "default.project.json").exists():
            self.rojo.init_default_project_json(root, name=root.name)
        result = self.rojo.serve(root, port=self.port_spin.value())
        self._show_result(result)

    def _stop_serve(self):
        result = self.rojo.stop_serve()
        self._show_result(result)

    def _show_result(self, result):
        lines = [
            f"ok={result.ok} code={result.returncode}",
            f"cmd: {' '.join(result.command)}" if result.command else "",
            result.stdout or "",
            result.stderr or "",
        ]
        text = "\n".join(l for l in lines if l)
        self.log_view.appendPlainText(text)
        if not result.ok:
            QMessageBox.warning(self, "Rojo", result.stderr or "Comando falló")
