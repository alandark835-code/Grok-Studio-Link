"""Performance static analyzer UI"""

from __future__ import annotations

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QPlainTextEdit, QMessageBox

from core.perf_analyzer import PerformanceAnalyzer
from core.project_manager import ProjectManager


class PerfPanel(QWidget):
    def __init__(self, pm: ProjectManager, parent=None):
        super().__init__(parent)
        self.pm = pm
        self.analyzer = PerformanceAnalyzer()
        layout = QVBoxLayout(self)
        title = QLabel("Performance Analyzer (estático)")
        title.setObjectName("title")
        layout.addWidget(title)
        sub = QLabel(
            "Busca patrones costosos en código. No mide FPS reales ni memoria en Studio."
        )
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        layout.addWidget(sub)
        btn = QPushButton("Analizar")
        btn.setObjectName("primary")
        btn.clicked.connect(self._run)
        layout.addWidget(btn)
        self.view = QPlainTextEdit()
        self.view.setReadOnly(True)
        layout.addWidget(self.view)

    def _run(self):
        if not self.pm.current_project:
            QMessageBox.warning(self, "Perf", "Abre un proyecto")
            return
        report = self.analyzer.analyze_tree(self.pm.current_project)
        lines = [f"Archivos: {report.files_scanned}", f"Hints: {len(report.hints)}", ""]
        for h in report.hints[:100]:
            lines.append(f"[{h.severity}] {h.file}:{h.line} — {h.message}")
        if not report.hints:
            lines.append("Sin patrones de las reglas actuales.")
        self.view.setPlainText("\n".join(lines))
