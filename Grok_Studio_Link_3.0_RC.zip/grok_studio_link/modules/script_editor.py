"""
Basic Script Editor for Luau / Lua files.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Signal
from PySide6.QtGui import QFont, QTextCharFormat, QColor, QSyntaxHighlighter
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QPlainTextEdit, QMessageBox, QFileDialog
)

from core.project_manager import ProjectManager
from core.logger import get_logger

log = get_logger()


class LuauHighlighter(QSyntaxHighlighter):
    """Very lightweight keyword highlighter for Luau."""

    KEYWORDS = [
        "and", "break", "do", "else", "elseif", "end", "false", "for",
        "function", "goto", "if", "in", "local", "nil", "not", "or",
        "repeat", "return", "then", "true", "until", "while",
        "continue", "export", "type", "typeof",
    ]

    def __init__(self, document):
        super().__init__(document)
        self.keyword_format = QTextCharFormat()
        self.keyword_format.setForeground(QColor("#cba6f7"))
        self.keyword_format.setFontWeight(700)

        self.string_format = QTextCharFormat()
        self.string_format.setForeground(QColor("#a6e3a1"))

        self.comment_format = QTextCharFormat()
        self.comment_format.setForeground(QColor("#6c7086"))

    def highlightBlock(self, text: str):
        # Comments
        if "--" in text:
            idx = text.find("--")
            self.setFormat(idx, len(text) - idx, self.comment_format)

        # Keywords
        import re
        for kw in self.KEYWORDS:
            for m in re.finditer(rf"\b{kw}\b", text):
                self.setFormat(m.start(), len(kw), self.keyword_format)

        # Simple strings
        for m in re.finditer(r'("([^"\\]|\\.)*"|\'([^\'\\]|\\.)*\')', text):
            self.setFormat(m.start(), m.end() - m.start(), self.string_format)


class ScriptEditor(QWidget):
    def __init__(self, project_manager: ProjectManager, parent=None):
        super().__init__(parent)
        self.pm = project_manager
        self.current_path: Optional[str] = None
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        header = QHBoxLayout()
        self.path_label = QLabel("Ningún archivo abierto")
        self.path_label.setObjectName("subtitle")
        header.addWidget(self.path_label)
        header.addStretch()

        self.btn_save = QPushButton("Guardar")
        self.btn_save.setObjectName("primary")
        self.btn_save.clicked.connect(self.save)
        self.btn_save.setEnabled(False)
        header.addWidget(self.btn_save)

        layout.addLayout(header)

        self.editor = QPlainTextEdit()
        font = QFont("Cascadia Code", 11)
        if not font.exactMatch():
            font = QFont("Consolas", 11)
        self.editor.setFont(font)
        self.editor.setPlaceholderText("Abre un archivo desde el Explorador de Proyectos…")
        self.highlighter = LuauHighlighter(self.editor.document())
        layout.addWidget(self.editor)

    def open_file(self, relative_path: str):
        try:
            content = self.pm.read_file(relative_path)
            self.editor.setPlainText(content)
            self.current_path = relative_path
            self.path_label.setText(relative_path)
            self.btn_save.setEnabled(True)
            log.info("Opened in editor: %s", relative_path)
        except Exception as e:
            QMessageBox.warning(self, "No se pudo abrir", str(e))

    def save(self):
        if not self.current_path:
            return
        try:
            content = self.editor.toPlainText()
            self.pm.write_file(self.current_path, content, overwrite=True)
            QMessageBox.information(self, "Guardado", f"Archivo guardado:\n{self.current_path}")
            log.info("Saved: %s", self.current_path)
        except Exception as e:
            QMessageBox.critical(self, "Error al guardar", str(e))
