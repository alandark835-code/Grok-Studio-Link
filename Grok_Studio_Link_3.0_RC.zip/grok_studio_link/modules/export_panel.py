"""
FREE MODE Export Center — PROJECT_STATE, CONTEXT, ERROR_REPORT, SOURCE ZIP.
"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QGroupBox, QPlainTextEdit, QMessageBox, QFileDialog
)
from pathlib import Path

from core.export_manager import ExportManager
from core.logger import get_logger

log = get_logger()


class ExportPanel(QWidget):
    def __init__(self, export_manager: ExportManager, parent=None):
        super().__init__(parent)
        self.exports = export_manager
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        title = QLabel("FREE MODE — Export Center")
        title.setObjectName("title")
        layout.addWidget(title)

        sub = QLabel(
            "Genera artefactos para compartir con Grok Web (sin API Key). "
            "Nunca incluye API Keys ni cookies."
        )
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        notes_box = QGroupBox("Notas de contexto (opcional)")
        nl = QVBoxLayout(notes_box)
        self.notes_edit = QPlainTextEdit()
        self.notes_edit.setPlaceholderText("Objetivo del proyecto, bugs actuales, lo que quieres que Grok revise…")
        self.notes_edit.setMaximumHeight(100)
        nl.addWidget(self.notes_edit)
        layout.addWidget(notes_box)

        btns = QHBoxLayout()
        b1 = QPushButton("PROJECT_STATE.md")
        b1.clicked.connect(self._state)
        btns.addWidget(b1)
        b2 = QPushButton("PROJECT_CONTEXT.md")
        b2.clicked.connect(self._context)
        btns.addWidget(b2)
        b3 = QPushButton("ERROR_REPORT.md")
        b3.clicked.connect(self._errors)
        btns.addWidget(b3)
        b4 = QPushButton("SOURCE_PACKAGE.zip")
        b4.setObjectName("primary")
        b4.clicked.connect(self._package)
        btns.addWidget(b4)
        layout.addLayout(btns)

        b_all = QPushButton("Exportar todo (FREE MODE bundle)")
        b_all.setObjectName("primary")
        b_all.clicked.connect(self._all)
        layout.addWidget(b_all)

        out_box = QGroupBox("Resultado")
        ol = QVBoxLayout(out_box)
        self.out_view = QPlainTextEdit()
        self.out_view.setReadOnly(True)
        ol.addWidget(self.out_view)
        layout.addWidget(out_box)
        layout.addStretch()

    def _state(self):
        try:
            path = self.exports.write_project_state()
            self.out_view.appendPlainText(f"OK → {path}")
            QMessageBox.information(self, "Export", f"Creado:\n{path}")
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))

    def _context(self):
        try:
            path = self.exports.write_project_context(self.notes_edit.toPlainText())
            self.out_view.appendPlainText(f"OK → {path}")
            QMessageBox.information(self, "Export", f"Creado:\n{path}")
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))

    def _errors(self):
        try:
            # Simple template; user can edit notes as errors lines
            raw = self.notes_edit.toPlainText().strip()
            errors = [l.strip() for l in raw.splitlines() if l.strip()] or ["(sin errores listados — plantilla)"]
            path = self.exports.write_error_report("Manual export", errors)
            self.out_view.appendPlainText(f"OK → {path}")
            QMessageBox.information(self, "Export", f"Creado:\n{path}")
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))

    def _package(self):
        try:
            path = self.exports.export_source_package()
            self.out_view.appendPlainText(f"OK → {path}")
            QMessageBox.information(self, "Export", f"ZIP creado:\n{path}")
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))

    def _all(self):
        try:
            paths = self.exports.export_all_free_mode(self.notes_edit.toPlainText())
            text = "Bundle FREE MODE:\n" + "\n".join(f"  {k}: {v}" for k, v in paths.items())
            self.out_view.appendPlainText(text)
            QMessageBox.information(self, "Export", text)
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))
