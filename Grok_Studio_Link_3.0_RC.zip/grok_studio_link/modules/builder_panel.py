"""Project Builder UI — scaffold Rojo layout"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QGroupBox, QPlainTextEdit, QMessageBox
)

from core.project_builder import ProjectBuilder
from core.project_manager import ProjectManager


class BuilderPanel(QWidget):
    def __init__(self, builder: ProjectBuilder, pm: ProjectManager, parent=None):
        super().__init__(parent)
        self.builder = builder
        self.pm = pm
        layout = QVBoxLayout(self)
        title = QLabel("Project Builder")
        title.setObjectName("title")
        layout.addWidget(title)
        sub = QLabel(
            "Crea estructura Rojo estándar: src/shared, src/server, src/client, "
            "Config.luau, Main server/client y default.project.json."
        )
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        btn = QPushButton("Scaffold proyecto actual")
        btn.setObjectName("primary")
        btn.clicked.connect(self._run)
        layout.addWidget(btn)

        box = QGroupBox("Resultado")
        bl = QVBoxLayout(box)
        self.view = QPlainTextEdit()
        self.view.setReadOnly(True)
        bl.addWidget(self.view)
        layout.addWidget(box)
        layout.addStretch()

    def _run(self):
        if not self.pm.current_project:
            QMessageBox.warning(self, "Proyecto", "Abre o crea un proyecto primero")
            return
        try:
            created = self.builder.scaffold(self.pm.current_project, self.pm.current_project.name)
            self.view.setPlainText("Creados/actualizados:\n" + "\n".join(f"  - {c}" for c in created))
            QMessageBox.information(self, "Builder", f"{len(created)} elemento(s) preparados")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
