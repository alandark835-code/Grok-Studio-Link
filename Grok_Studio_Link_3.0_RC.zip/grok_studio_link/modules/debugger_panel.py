"""Static AI Debugger panel — Luau heuristics."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QPlainTextEdit, QMessageBox, QHBoxLayout
)

from core.luau_analyzer import LuauAnalyzer
from core.project_manager import ProjectManager
from core.export_manager import ExportManager


class DebuggerPanel(QWidget):
    def __init__(self, pm: ProjectManager, exports: ExportManager, parent=None):
        super().__init__(parent)
        self.pm = pm
        self.exports = exports
        self.analyzer = LuauAnalyzer()
        layout = QVBoxLayout(self)
        title = QLabel("AI Debugger (estático)")
        title.setObjectName("title")
        layout.addWidget(title)
        sub = QLabel(
            "Análisis heurístico de scripts Luau/Lua. No sustituye el typechecker de Studio "
            "ni un linter oficial. Clasifica hallazgos: CRITICAL/HIGH/MEDIUM/LOW/INFO."
        )
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        layout.addWidget(sub)
        row = QHBoxLayout()
        btn = QPushButton("Analizar proyecto")
        btn.setObjectName("primary")
        btn.clicked.connect(self._run)
        row.addWidget(btn)
        btn_err = QPushButton("Exportar como ERROR_REPORT")
        btn_err.clicked.connect(self._export)
        row.addWidget(btn_err)
        layout.addLayout(row)
        self.view = QPlainTextEdit()
        self.view.setReadOnly(True)
        layout.addWidget(self.view)
        self._last_lines: list[str] = []

    def _run(self):
        if not self.pm.current_project:
            QMessageBox.warning(self, "Debugger", "Abre un proyecto primero")
            return
        report = self.analyzer.analyze_tree(self.pm.current_project)
        lines = [f"Archivos escaneados: {report.files_scanned}", f"Hallazgos: {len(report.findings)}", ""]
        order = ["CRITICAL", "HIGH", "MEDIUM", "LOW", "INFO"]
        grouped = report.by_severity()
        for sev in order:
            items = grouped.get(sev, [])
            if not items:
                continue
            lines.append(f"=== {sev} ({len(items)}) ===")
            for f in items[:80]:
                lines.append(f"  [{f.code}] {f.file}:{f.line} — {f.message}")
            lines.append("")
        if not report.findings:
            lines.append("Sin hallazgos con las reglas actuales.")
        self._last_lines = lines
        self.view.setPlainText("\n".join(lines))

    def _export(self):
        if not self._last_lines:
            QMessageBox.information(self, "Debugger", "Ejecuta un análisis primero")
            return
        try:
            path = self.exports.write_error_report(
                "Static Luau analysis",
                [l.strip() for l in self._last_lines if l.strip()],
            )
            QMessageBox.information(self, "Export", f"Escrito:\n{path}")
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))
