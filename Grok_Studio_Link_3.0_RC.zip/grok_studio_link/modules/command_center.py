"""
AI Command Center — import, preview and apply Grok JSON tasks.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Signal, Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QPlainTextEdit, QFileDialog, QMessageBox, QGroupBox
)

from core.task_engine import TaskEngine, TaskReport
from core.logger import get_logger

log = get_logger()


class CommandCenter(QWidget):
    task_applied = Signal(object)  # TaskReport

    def __init__(self, task_engine: TaskEngine, parent=None):
        super().__init__(parent)
        self.engine = task_engine
        self.current_task: Optional[dict] = None
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("AI Command Center")
        title.setObjectName("title")
        layout.addWidget(title)

        subtitle = QLabel(
            "Importa tareas JSON generadas por Grok. "
            "Revisa los cambios y aplícalos de forma segura."
        )
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        # Buttons
        btn_row = QHBoxLayout()
        self.btn_import = QPushButton("Importar JSON…")
        self.btn_import.clicked.connect(self.import_task)
        btn_row.addWidget(self.btn_import)

        self.btn_preview = QPushButton("Validar / Previsualizar")
        self.btn_preview.clicked.connect(self.preview_task)
        self.btn_preview.setEnabled(False)
        btn_row.addWidget(self.btn_preview)

        self.btn_apply = QPushButton("Aplicar tarea")
        self.btn_apply.setObjectName("primary")
        self.btn_apply.clicked.connect(self.apply_task)
        self.btn_apply.setEnabled(False)
        btn_row.addWidget(self.btn_apply)

        btn_row.addStretch()
        layout.addLayout(btn_row)

        # Preview area
        group = QGroupBox("Vista previa de la tarea")
        g_layout = QVBoxLayout(group)
        self.preview = QPlainTextEdit()
        self.preview.setReadOnly(True)
        self.preview.setPlaceholderText("Aquí aparecerá el resumen de la tarea importada…")
        g_layout.addWidget(self.preview)
        layout.addWidget(group)

        # Report area
        report_group = QGroupBox("Informe de ejecución")
        r_layout = QVBoxLayout(report_group)
        self.report_view = QPlainTextEdit()
        self.report_view.setReadOnly(True)
        r_layout.addWidget(self.report_view)
        layout.addWidget(report_group)

    def import_task(self):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Seleccionar tarea JSON",
            str(Path.home()),
            "JSON Files (*.json);;All Files (*)",
        )
        if not path:
            return
        try:
            self.current_task = self.engine.load_task(Path(path))
            self.preview.setPlainText("\n".join(self.engine.preview(self.current_task)))
            self.btn_preview.setEnabled(True)
            self.btn_apply.setEnabled(True)
            self.report_view.clear()
            log.info("Task imported from %s", path)
        except Exception as e:
            QMessageBox.critical(self, "Error al importar", str(e))
            log.error("Import failed: %s", e)
            self.current_task = None
            self.btn_preview.setEnabled(False)
            self.btn_apply.setEnabled(False)

    def preview_task(self):
        if not self.current_task:
            return
        try:
            # Re-validate
            self.engine._validate_schema(self.current_task)
            lines = self.engine.preview(self.current_task)
            lines.append("\n✓ Schema válido. Listo para aplicar.")
            self.preview.setPlainText("\n".join(lines))
        except Exception as e:
            QMessageBox.warning(self, "Validación fallida", str(e))

    def apply_task(self):
        if not self.current_task:
            return

        summary = self.current_task.get("summary", "")
        project = self.current_task.get("project", "")
        reply = QMessageBox.question(
            self,
            "Confirmar aplicación",
            f"¿Aplicar la tarea al proyecto «{project}»?\n\n"
            f"{summary}\n\n"
            f"Se creará un backup automático antes de escribir archivos.",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return

        try:
            report: TaskReport = self.engine.apply(self.current_task, create_backup=True)
            self._show_report(report)
            self.task_applied.emit(report)
        except Exception as e:
            QMessageBox.critical(self, "Error al aplicar", str(e))
            log.error("Apply failed: %s", e)

    def _show_report(self, report: TaskReport):
        lines = [
            f"Proyecto : {report.project}",
            f"Resumen  : {report.summary}",
            f"Éxito    : {'SÍ' if report.success else 'NO'}",
        ]
        if report.backup_path:
            lines.append(f"Backup   : {report.backup_path}")
        lines.append("")
        lines.append("Operaciones:")
        for op in report.operations:
            status = "✓" if op.success else "✗"
            lines.append(f"  {status} [{op.action}] {op.path} — {op.message}")
        if report.errors:
            lines.append("")
            lines.append("Errores:")
            for err in report.errors:
                lines.append(f"  • {err}")
        self.report_view.setPlainText("\n".join(lines))

        if report.success:
            QMessageBox.information(self, "Tarea aplicada", "La tarea se aplicó correctamente.")
        else:
            QMessageBox.warning(
                self,
                "Tarea con errores",
                "Algunas operaciones fallaron. Revisa el informe.",
            )
