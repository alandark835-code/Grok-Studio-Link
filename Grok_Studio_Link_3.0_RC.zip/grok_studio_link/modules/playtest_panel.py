"""Guided Playtest Center — checklist + report export (no fake Studio control)."""

from __future__ import annotations

from datetime import datetime, timezone

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QPlainTextEdit,
    QListWidget, QListWidgetItem, QHBoxLayout, QMessageBox
)
from PySide6.QtCore import Qt

from core.project_manager import ProjectManager
from core.export_manager import ExportManager


CHECKLIST = [
    "El place abre en Roblox Studio sin errores de consola al cargar",
    "Scripts server se ejecutan (prints/logs visibles en Server)",
    "Scripts client se ejecutan en Play solo",
    "Remotes: el servidor rechaza datos inválidos del cliente",
    "DataStore (si aplica): carga/guardado sin errores",
    "UI visible y usable en resolución mínima",
    "No hay loops sin wait que congelen Studio",
    "Rojo serve / sync refleja cambios (si usas Rojo)",
]


class PlaytestPanel(QWidget):
    def __init__(self, pm: ProjectManager, exports: ExportManager, parent=None):
        super().__init__(parent)
        self.pm = pm
        self.exports = exports
        layout = QVBoxLayout(self)
        title = QLabel("Playtest Center")
        title.setObjectName("title")
        layout.addWidget(title)
        sub = QLabel(
            "Guía de pruebas manuales + informe. "
            "GSL no declara playtest exitoso sin evidencia: marca tú cada ítem tras probar en Studio."
        )
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        self.list = QListWidget()
        for text in CHECKLIST:
            item = QListWidgetItem(text)
            item.setFlags(item.flags() | Qt.ItemIsUserCheckable)
            item.setCheckState(Qt.Unchecked)
            self.list.addItem(item)
        layout.addWidget(self.list)

        layout.addWidget(QLabel("Notas / logs observados:"))
        self.notes = QPlainTextEdit()
        self.notes.setPlaceholderText(
            "Pega aquí errores de la consola de Studio, pasos fallidos, etc."
        )
        layout.addWidget(self.notes)

        row = QHBoxLayout()
        btn = QPushButton("Generar PLAYTEST_REPORT.md")
        btn.setObjectName("primary")
        btn.clicked.connect(self._export)
        row.addWidget(btn)
        layout.addLayout(row)

    def _export(self):
        if not self.pm.current_project:
            QMessageBox.warning(self, "Playtest", "Abre un proyecto primero")
            return
        passed = []
        failed = []
        for i in range(self.list.count()):
            item = self.list.item(i)
            if item.checkState() == Qt.Checked:
                passed.append(item.text())
            else:
                failed.append(item.text())

        lines = [
            f"# PLAYTEST_REPORT — {self.pm.current_project.name}",
            f"Generated: {datetime.now(timezone.utc).isoformat()}",
            "",
            f"Passed: {len(passed)}/{len(passed) + len(failed)}",
            "",
            "## Passed",
        ]
        lines.extend([f"- [x] {x}" for x in passed] or ["- (none)"])
        lines.append("")
        lines.append("## Not checked / failed")
        lines.extend([f"- [ ] {x}" for x in failed] or ["- (none)"])
        lines.append("")
        lines.append("## Notes")
        lines.append(self.notes.toPlainText().strip() or "(sin notas)")
        lines.append("")
        lines.append("## Honesty")
        lines.append(
            "This report is user-attested. GSL did not drive Studio automatically "
            "unless MCP tools were used separately."
        )

        path = self.pm.current_project / "PLAYTEST_REPORT.md"
        path.write_text("\n".join(lines), encoding="utf-8")
        try:
            self.exports.write_error_report(
                "Playtest report snapshot",
                [l for l in lines if l.startswith("-")],
                extra={"passed": len(passed), "pending": len(failed)},
            )
        except Exception:
            pass
        QMessageBox.information(self, "Playtest", f"Informe escrito:\n{path}")
