"""ZIP Package Inspector UI"""

from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QGroupBox, QPlainTextEdit, QFileDialog, QMessageBox, QCheckBox
)

from core.zip_inspector import ZipInspector
from core.project_manager import ProjectManager
from core.backup_manager import BackupManager
from core.logger import get_logger

log = get_logger()


class ZipPanel(QWidget):
    def __init__(
        self,
        inspector: ZipInspector,
        project_manager: ProjectManager,
        backups: BackupManager,
        parent=None,
    ):
        super().__init__(parent)
        self.inspector = inspector
        self.pm = project_manager
        self.backups = backups
        self._last_path: Path | None = None
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        title = QLabel("ZIP Package Inspector")
        title.setObjectName("title")
        layout.addWidget(title)
        sub = QLabel(
            "Inspecciona paquetes de Grok / SOURCE_PACKAGE de forma segura. "
            "No ejecuta código del ZIP."
        )
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        row = QHBoxLayout()
        btn_open = QPushButton("Abrir ZIP…")
        btn_open.clicked.connect(self._open)
        row.addWidget(btn_open)
        self.chk_overwrite = QCheckBox("Permitir sobrescribir al extraer")
        row.addWidget(self.chk_overwrite)
        btn_extract = QPushButton("Extraer al proyecto actual")
        btn_extract.setObjectName("primary")
        btn_extract.clicked.connect(self._extract)
        row.addWidget(btn_extract)
        layout.addLayout(row)

        box = QGroupBox("Informe")
        bl = QVBoxLayout(box)
        self.view = QPlainTextEdit()
        self.view.setReadOnly(True)
        bl.addWidget(self.view)
        layout.addWidget(box)

    def _open(self):
        path, _ = QFileDialog.getOpenFileName(self, "ZIP", str(Path.home()), "ZIP (*.zip)")
        if not path:
            return
        self._last_path = Path(path)
        report = self.inspector.inspect(self._last_path)
        lines = [
            f"Archivo: {report.path}",
            f"OK: {report.ok}",
            f"Miembros: {len(report.members)}",
            f"Scripts Luau/Lua: {len(report.scripts)}",
            f"JSON: {len(report.json_files)}",
            f"default.project.json: {report.has_default_project}",
            "",
            "Scripts:",
        ]
        lines.extend(f"  - {s}" for s in report.scripts[:40])
        lines.append("")
        lines.append("Advertencias:")
        lines.extend([f"  - {w}" for w in report.warnings] or ["  (ninguna)"])
        lines.append("")
        lines.append("Errores:")
        lines.extend([f"  - {e}" for e in report.errors] or ["  (ninguno)"])
        self.view.setPlainText("\n".join(lines))

    def _extract(self):
        if not self._last_path:
            QMessageBox.warning(self, "ZIP", "Abre un ZIP primero")
            return
        if not self.pm.current_project:
            QMessageBox.warning(self, "Proyecto", "Abre un proyecto destino primero")
            return
        reply = QMessageBox.question(
            self,
            "Extraer",
            f"¿Extraer miembros seguros de\n{self._last_path.name}\n"
            f"en el proyecto «{self.pm.current_project.name}»?\n"
            "Se creará un backup automático.",
        )
        if reply != QMessageBox.Yes:
            return
        try:
            self.backups.create_backup(self.pm.current_project, label="pre_zip_extract")
            written = self.inspector.extract_to_project(
                self._last_path,
                self.pm.current_project,
                overwrite=self.chk_overwrite.isChecked(),
            )
            self.view.appendPlainText("\nExtraídos:\n" + "\n".join(f"  - {w}" for w in written))
            QMessageBox.information(self, "ZIP", f"Extraídos {len(written)} archivo(s)")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
