"""Settings + health check"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QPlainTextEdit, QGroupBox
)

from core.config import AppConfig
from core.health import check_health


class SettingsPanel(QWidget):
    def __init__(self, config: AppConfig, parent=None):
        super().__init__(parent)
        self.config = config
        layout = QVBoxLayout(self)
        title = QLabel("Settings & Health")
        title.setObjectName("title")
        layout.addWidget(title)

        info = QGroupBox("Rutas")
        il = QVBoxLayout(info)
        self.paths = QLabel(
            f"App: {config.root_dir}\n"
            f"Workspace: {config.workspace_dir}\n"
            f"Backups: {config.backups_dir}\n"
            f"Versión: {config.version}"
        )
        self.paths.setWordWrap(True)
        il.addWidget(self.paths)
        layout.addWidget(info)

        btn = QPushButton("Comprobar dependencias")
        btn.setObjectName("primary")
        btn.clicked.connect(self._health)
        layout.addWidget(btn)
        self.view = QPlainTextEdit()
        self.view.setReadOnly(True)
        layout.addWidget(self.view)
        layout.addStretch()
        self._health()

    def _health(self):
        report = check_health()
        header = "Estado general: OK" if report.ok else "Estado general: FALTAN DEPENDENCIAS REQUERIDAS"
        self.view.setPlainText(header + "\n\n" + "\n".join(report.lines))
