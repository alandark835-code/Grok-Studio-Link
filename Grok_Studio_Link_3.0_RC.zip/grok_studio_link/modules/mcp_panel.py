"""
MCP Panel — connection status, tool list and safe tool invocation UI.
"""

from __future__ import annotations

import json
from typing import Any, Dict, Optional

from PySide6.QtCore import Signal, Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QListWidget, QListWidgetItem, QPlainTextEdit, QMessageBox,
    QGroupBox, QFormLayout, QLineEdit, QSplitter
)

from mcp.client import MCPClient
from mcp.connection_manager import ConnectionState
from core.logger import get_logger

log = get_logger()


class MCPPanel(QWidget):
    connection_changed = Signal(dict)

    def __init__(self, mcp_client: MCPClient, parent=None):
        super().__init__(parent)
        self.client = mcp_client
        self._selected_tool: Optional[str] = None
        self._build_ui()
        self.refresh_status()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("Roblox Studio MCP")
        title.setObjectName("title")
        layout.addWidget(title)

        subtitle = QLabel(
            "Conecta con el servidor MCP integrado de Roblox Studio (STDIO). "
            "Las herramientas se descubren automáticamente; no se inventan nombres."
        )
        subtitle.setObjectName("subtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        # Status + buttons
        status_group = QGroupBox("Estado de conexión")
        s_layout = QVBoxLayout(status_group)

        self.status_label = QLabel("Desconectado")
        self.status_label.setWordWrap(True)
        s_layout.addWidget(self.status_label)

        self.sdk_label = QLabel("")
        self.sdk_label.setObjectName("subtitle")
        s_layout.addWidget(self.sdk_label)

        btn_row = QHBoxLayout()
        self.btn_connect = QPushButton("Conectar")
        self.btn_connect.setObjectName("primary")
        self.btn_connect.clicked.connect(self._on_connect)
        btn_row.addWidget(self.btn_connect)

        self.btn_disconnect = QPushButton("Desconectar")
        self.btn_disconnect.clicked.connect(self._on_disconnect)
        self.btn_disconnect.setEnabled(False)
        btn_row.addWidget(self.btn_disconnect)

        self.btn_refresh = QPushButton("Refrescar tools")
        self.btn_refresh.clicked.connect(self._on_refresh_tools)
        self.btn_refresh.setEnabled(False)
        btn_row.addWidget(self.btn_refresh)

        btn_row.addStretch()
        s_layout.addLayout(btn_row)
        layout.addWidget(status_group)

        # Splitter: tools list + call panel
        splitter = QSplitter(Qt.Horizontal)

        # Tools list
        tools_group = QGroupBox("Herramientas descubiertas")
        t_layout = QVBoxLayout(tools_group)
        self.tools_list = QListWidget()
        self.tools_list.currentItemChanged.connect(self._on_tool_selected)
        t_layout.addWidget(self.tools_list)
        splitter.addWidget(tools_group)

        # Call panel
        call_group = QGroupBox("Invocar herramienta")
        c_layout = QVBoxLayout(call_group)

        self.tool_name_label = QLabel("Ninguna seleccionada")
        c_layout.addWidget(self.tool_name_label)

        self.tool_desc_label = QLabel("")
        self.tool_desc_label.setObjectName("subtitle")
        self.tool_desc_label.setWordWrap(True)
        c_layout.addWidget(self.tool_desc_label)

        c_layout.addWidget(QLabel("Argumentos (JSON):"))
        self.args_edit = QPlainTextEdit()
        self.args_edit.setPlaceholderText('{\n  "path": "ServerScriptService.Main"\n}')
        self.args_edit.setMaximumHeight(120)
        c_layout.addWidget(self.args_edit)

        self.btn_call = QPushButton("Ejecutar tool")
        self.btn_call.setObjectName("primary")
        self.btn_call.clicked.connect(self._on_call_tool)
        self.btn_call.setEnabled(False)
        c_layout.addWidget(self.btn_call)

        c_layout.addWidget(QLabel("Resultado:"))
        self.result_view = QPlainTextEdit()
        self.result_view.setReadOnly(True)
        c_layout.addWidget(self.result_view)

        splitter.addWidget(call_group)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)
        layout.addWidget(splitter)

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def refresh_status(self):
        status = self.client.connection.status()
        sdk_ok = self.client.is_sdk_available()

        self.status_label.setText(
            f"Estado: {status.state.value.upper()}\n{status.message}"
            + (f"\nDetalle: {status.error_detail}" if status.error_detail else "")
        )
        self.sdk_label.setText(
            "SDK mcp: disponible" if sdk_ok else "SDK mcp: NO instalado (pip install mcp)"
        )

        connected = status.state == ConnectionState.CONNECTED
        self.btn_connect.setEnabled(not connected)
        self.btn_disconnect.setEnabled(connected)
        self.btn_refresh.setEnabled(connected)

        self._reload_tools_list()

    def _reload_tools_list(self):
        self.tools_list.clear()
        for t in self.client.registry.all():
            item = QListWidgetItem(t.name)
            item.setData(Qt.UserRole, t.name)
            item.setToolTip(t.description)
            self.tools_list.addItem(item)
        self.btn_call.setEnabled(False)
        self._selected_tool = None
        self.tool_name_label.setText("Ninguna seleccionada")
        self.tool_desc_label.setText("")

    def _on_connect(self):
        self.btn_connect.setEnabled(False)
        self.status_label.setText("Conectando…")
        try:
            result = self.client.connect()
            self.refresh_status()
            self.connection_changed.emit(result)
            if result.get("state") == "connected":
                QMessageBox.information(
                    self,
                    "Conectado",
                    f"MCP conectado.\nHerramientas: {result.get('tools_count', 0)}\n\n"
                    + "\n".join(result.get("tools", [])[:15]),
                )
            else:
                QMessageBox.warning(
                    self,
                    "No conectado",
                    result.get("error_detail") or result.get("message") or "Fallo de conexión",
                )
        except Exception as e:
            log.exception("Connect UI error")
            QMessageBox.critical(self, "Error", str(e))
            self.refresh_status()

    def _on_disconnect(self):
        result = self.client.disconnect()
        self.refresh_status()
        self.connection_changed.emit(result)
        self.result_view.clear()

    def _on_refresh_tools(self):
        try:
            count = self.client.refresh_tools()
            self.refresh_status()
            QMessageBox.information(self, "Tools", f"{count} herramienta(s) actualizada(s).")
        except Exception as e:
            QMessageBox.warning(self, "Error", str(e))

    def _on_tool_selected(self, current: QListWidgetItem, previous: QListWidgetItem):
        if not current:
            self.btn_call.setEnabled(False)
            return
        name = current.data(Qt.UserRole)
        info = self.client.registry.get(name)
        self._selected_tool = name
        self.tool_name_label.setText(name)
        if info:
            self.tool_desc_label.setText(info.description or "(sin descripción)")
            # Pre-fill a minimal JSON skeleton from schema if possible
            schema = info.input_schema or {}
            props = schema.get("properties") or {}
            skeleton = {k: "" for k in props.keys()} if props else {}
            self.args_edit.setPlainText(json.dumps(skeleton, indent=2) if skeleton else "{}")
        self.btn_call.setEnabled(True)

    def _on_call_tool(self):
        if not self._selected_tool:
            return
        raw = self.args_edit.toPlainText().strip() or "{}"
        try:
            args = json.loads(raw)
            if not isinstance(args, dict):
                raise ValueError("Los argumentos deben ser un objeto JSON")
        except Exception as e:
            QMessageBox.warning(self, "JSON inválido", str(e))
            return

        reply = QMessageBox.question(
            self,
            "Confirmar invocación",
            f"¿Ejecutar la herramienta «{self._selected_tool}»?\n\n"
            f"Argumentos:\n{json.dumps(args, indent=2)[:500]}",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return

        try:
            result = self.client.call_tool(self._selected_tool, args)
            if isinstance(result, (dict, list)):
                text = json.dumps(result, indent=2, ensure_ascii=False)
            else:
                text = str(result)
            self.result_view.setPlainText(text)
            log.info("Tool %s executed successfully", self._selected_tool)
        except Exception as e:
            self.result_view.setPlainText(f"ERROR: {e}")
            log.error("Tool call failed: %s", e)
            QMessageBox.warning(self, "Error al ejecutar", str(e))
