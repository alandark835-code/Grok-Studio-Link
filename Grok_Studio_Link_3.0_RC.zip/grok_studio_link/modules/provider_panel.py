"""
AI Provider Manager UI — FREE / API switch for GSL 3.0 Alpha.
"""

from __future__ import annotations

from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QGroupBox, QLineEdit, QFormLayout, QMessageBox, QComboBox, QPlainTextEdit
)

from core.ai_provider import AIProviderManager, ProviderMode
from core.logger import get_logger

log = get_logger()


class ProviderPanel(QWidget):
    mode_changed = Signal(str)

    def __init__(self, manager: AIProviderManager, parent=None):
        super().__init__(parent)
        self.manager = manager
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        title = QLabel("AI Provider Manager")
        title.setObjectName("title")
        layout.addWidget(title)

        sub = QLabel(
            "FREE MODE funciona sin API Key (Grok Web + archivos). "
            "API MODE es opcional. LOCAL AI llega en una fase posterior."
        )
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        # Mode selector
        mode_box = QGroupBox("Modalidad activa")
        m_layout = QVBoxLayout(mode_box)
        row = QHBoxLayout()
        self.mode_combo = QComboBox()
        self.mode_combo.addItem("FREE MODE (recomendado)", ProviderMode.FREE.value)
        self.mode_combo.addItem("API MODE (opcional)", ProviderMode.API.value)
        self.mode_combo.addItem("LOCAL AI MODE (futuro)", ProviderMode.LOCAL.value)
        row.addWidget(self.mode_combo)
        btn_apply = QPushButton("Aplicar modalidad")
        btn_apply.setObjectName("primary")
        btn_apply.clicked.connect(self._apply_mode)
        row.addWidget(btn_apply)
        m_layout.addLayout(row)

        self.status_label = QLabel("")
        self.status_label.setWordWrap(True)
        m_layout.addWidget(self.status_label)
        layout.addWidget(mode_box)

        # API config
        api_box = QGroupBox("Configuración API (opcional)")
        form = QFormLayout(api_box)
        self.endpoint_edit = QLineEdit()
        self.endpoint_edit.setPlaceholderText("https://api.x.ai/v1")
        form.addRow("Endpoint:", self.endpoint_edit)
        self.model_edit = QLineEdit()
        self.model_edit.setPlaceholderText("nombre-de-modelo (verificar docs oficiales)")
        form.addRow("Modelo:", self.model_edit)
        self.key_edit = QLineEdit()
        self.key_edit.setEchoMode(QLineEdit.Password)
        self.key_edit.setPlaceholderText("API Key (solo en memoria en Alpha 0.1)")
        form.addRow("API Key:", self.key_edit)

        api_btns = QHBoxLayout()
        btn_save = QPushButton("Guardar config API")
        btn_save.clicked.connect(self._save_api)
        api_btns.addWidget(btn_save)
        btn_clear = QPushButton("Borrar Key de memoria")
        btn_clear.clicked.connect(self._clear_key)
        api_btns.addWidget(btn_clear)
        btn_ping = QPushButton("Probar config")
        btn_ping.clicked.connect(self._ping)
        api_btns.addWidget(btn_ping)
        form.addRow(api_btns)
        layout.addWidget(api_box)

        # FREE MODE help
        free_box = QGroupBox("Artefactos FREE MODE")
        fl = QVBoxLayout(free_box)
        self.free_info = QPlainTextEdit()
        self.free_info.setReadOnly(True)
        self.free_info.setMaximumHeight(120)
        fl.addWidget(self.free_info)
        layout.addWidget(free_box)

        layout.addStretch()

    def refresh(self):
        st = self.manager.status()
        idx = self.mode_combo.findData(st.mode.value)
        if idx >= 0:
            self.mode_combo.setCurrentIndex(idx)
        self.status_label.setText(f"{st.label}\n{st.detail}")
        if st.last_error:
            self.status_label.setText(self.status_label.text() + f"\n⚠ {st.last_error}")

        paths = self.manager.export_free_mode_bundle_paths()
        lines = ["Intercambio de archivos con Grok Web:"] + [f"  • {k}: {v}" for k, v in paths.items()]
        self.free_info.setPlainText("\n".join(lines))

        # Don't put key back into the field
        self.endpoint_edit.setText(st.api_endpoint or self.manager._api.endpoint)
        self.model_edit.setText(st.api_model or "")

    def _apply_mode(self):
        value = self.mode_combo.currentData()
        try:
            mode = ProviderMode(value)
        except ValueError:
            mode = ProviderMode.FREE
        st = self.manager.set_mode(mode)
        self.refresh()
        self.mode_changed.emit(st.mode.value)
        if mode == ProviderMode.LOCAL:
            QMessageBox.information(
                self,
                "LOCAL AI",
                "LOCAL AI MODE está reservado para una fase posterior.\n"
                "Se mantiene la modalidad anterior.",
            )

    def _save_api(self):
        st = self.manager.configure_api(
            endpoint=self.endpoint_edit.text().strip(),
            model=self.model_edit.text().strip(),
            api_key=self.key_edit.text(),
        )
        self.key_edit.clear()  # don't leave key visible
        self.refresh()
        QMessageBox.information(
            self,
            "API",
            "Configuración guardada.\n"
            "La API Key permanece solo en memoria en Alpha 0.1 "
            "(no se escribe en archivos de proyecto).",
        )
        self.mode_changed.emit(st.mode.value)

    def _clear_key(self):
        self.manager.clear_api_key()
        self.key_edit.clear()
        self.refresh()
        QMessageBox.information(self, "API Key", "Key eliminada de la memoria.")

    def _ping(self):
        result = self.manager.try_api_ping()
        QMessageBox.information(
            self,
            "Prueba de configuración",
            result.get("message", str(result)),
        )
        self.refresh()
