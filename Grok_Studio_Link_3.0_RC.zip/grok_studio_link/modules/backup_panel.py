"""Backup Center UI"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QListWidget, QHBoxLayout, QMessageBox
)

from core.backup_manager import BackupManager
from core.project_manager import ProjectManager


class BackupPanel(QWidget):
    def __init__(self, backups: BackupManager, pm: ProjectManager, parent=None):
        super().__init__(parent)
        self.backups = backups
        self.pm = pm
        layout = QVBoxLayout(self)
        title = QLabel("Backup Center")
        title.setObjectName("title")
        layout.addWidget(title)
        sub = QLabel("Backups en carpeta dedicada. Restaurar mueve el proyecto actual a un lado por seguridad.")
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        layout.addWidget(sub)

        row = QHBoxLayout()
        b1 = QPushButton("Actualizar lista")
        b1.clicked.connect(self.refresh)
        row.addWidget(b1)
        b2 = QPushButton("Crear backup ahora")
        b2.setObjectName("primary")
        b2.clicked.connect(self._create)
        row.addWidget(b2)
        b3 = QPushButton("Restaurar seleccionado")
        b3.clicked.connect(self._restore)
        row.addWidget(b3)
        layout.addLayout(row)

        self.list = QListWidget()
        layout.addWidget(self.list)
        self.refresh()

    def refresh(self):
        self.list.clear()
        name = self.pm.current_project.name if self.pm.current_project else None
        for p in self.backups.list_backups(name):
            self.list.addItem(str(p))

    def _create(self):
        if not self.pm.current_project:
            QMessageBox.warning(self, "Backup", "Abre un proyecto")
            return
        try:
            dest = self.backups.create_backup(self.pm.current_project, label="manual")
            self.refresh()
            QMessageBox.information(self, "Backup", f"Creado:\n{dest}")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def _restore(self):
        item = self.list.currentItem()
        if not item:
            QMessageBox.warning(self, "Backup", "Selecciona un backup")
            return
        if not self.pm.current_project:
            QMessageBox.warning(self, "Backup", "Abre el proyecto destino")
            return
        from pathlib import Path
        backup = Path(item.text())
        reply = QMessageBox.question(
            self,
            "Restaurar",
            f"¿Restaurar\n{backup.name}\nsobre\n{self.pm.current_project}?\n"
            "El proyecto actual se renombrará como seguridad.",
        )
        if reply != QMessageBox.Yes:
            return
        try:
            self.backups.restore_backup(backup, self.pm.current_project)
            QMessageBox.information(self, "Backup", "Restauración completada")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))
