"""
Project Explorer — tree view of the current project.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from PySide6.QtCore import Signal, Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTreeWidget, QTreeWidgetItem, QInputDialog, QMessageBox
)

from core.project_manager import ProjectManager
from core.logger import get_logger

log = get_logger()


class ProjectExplorer(QWidget):
    file_selected = Signal(str)  # relative path

    def __init__(self, project_manager: ProjectManager, parent=None):
        super().__init__(parent)
        self.pm = project_manager
        self._build_ui()
        self.refresh_projects()

    def _build_ui(self):
        layout = QVBoxLayout(self)

        header = QHBoxLayout()
        title = QLabel("Proyectos")
        title.setObjectName("title")
        header.addWidget(title)
        header.addStretch()

        self.btn_new = QPushButton("Nuevo")
        self.btn_new.clicked.connect(self.create_project)
        header.addWidget(self.btn_new)

        self.btn_refresh = QPushButton("Actualizar")
        self.btn_refresh.clicked.connect(self.refresh_projects)
        header.addWidget(self.btn_refresh)

        layout.addLayout(header)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Nombre"])
        self.tree.itemDoubleClicked.connect(self._on_double_click)
        layout.addWidget(self.tree)

    def refresh_projects(self):
        self.tree.clear()
        for proj in self.pm.list_projects():
            item = QTreeWidgetItem([proj.name])
            item.setData(0, Qt.UserRole, str(proj))
            item.setData(0, Qt.UserRole + 1, "project")
            self.tree.addTopLevelItem(item)
            # Lazy: only show top level; expand later if needed
        if self.pm.current_project:
            self._select_current()

    def _select_current(self):
        name = self.pm.current_project.name if self.pm.current_project else None
        if not name:
            return
        for i in range(self.tree.topLevelItemCount()):
            item = self.tree.topLevelItem(i)
            if item.text(0) == name:
                self.tree.setCurrentItem(item)
                break

    def create_project(self):
        name, ok = QInputDialog.getText(self, "Nuevo proyecto", "Nombre del proyecto:")
        if not ok or not name.strip():
            return
        try:
            self.pm.create_project(name.strip())
            self.refresh_projects()
            QMessageBox.information(self, "Proyecto creado", f"«{name}» creado correctamente.")
        except Exception as e:
            QMessageBox.critical(self, "Error", str(e))

    def _on_double_click(self, item: QTreeWidgetItem, column: int):
        kind = item.data(0, Qt.UserRole + 1)
        if kind == "project":
            try:
                self.pm.open_project(item.text(0))
                self._populate_project_tree(item)
                log.info("Project opened: %s", item.text(0))
            except Exception as e:
                QMessageBox.warning(self, "Error", str(e))
        elif kind == "file":
            rel = item.data(0, Qt.UserRole)
            if rel:
                self.file_selected.emit(rel)

    def _populate_project_tree(self, project_item: QTreeWidgetItem):
        project_item.takeChildren()
        if not self.pm.current_project:
            return
        root = self.pm.current_project
        for path in sorted(root.rglob("*")):
            if path.is_dir():
                continue
            rel = str(path.relative_to(root)).replace("\\", "/")
            child = QTreeWidgetItem([rel])
            child.setData(0, Qt.UserRole, rel)
            child.setData(0, Qt.UserRole + 1, "file")
            project_item.addChild(child)
        project_item.setExpanded(True)
