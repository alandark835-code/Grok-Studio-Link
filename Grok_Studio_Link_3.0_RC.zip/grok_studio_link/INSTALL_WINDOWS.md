# Cómo instalar y ejecutar GROK STUDIO LINK 3.0 Beta (Windows)

## 1. Python

1. Descarga Python 3.12 desde https://www.python.org/downloads/
2. En el instalador marca **Add python.exe to PATH**
3. Abre PowerShell nueva y comprueba:

```powershell
python --version
python -m pip --version
```

## 2. Abrir la carpeta del proyecto

```powershell
cd ruta\donde\descomprimiste\grok_studio_link
```

## 3. Entorno virtual (recomendado)

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
```

Si PowerShell bloquea scripts:

```powershell
Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
```

## 4. Instalar dependencias

### Opción A — script automático

Doble clic o:

```powershell
.\install_deps.bat
```

### Opción B — manual

```powershell
python -m pip install -r requirements.txt
```

### Si `mcp` falla

El nombre correcto del paquete es **`mcp`** (Model Context Protocol SDK).

Prueba en este orden:

```powershell
python -m pip install --upgrade pip setuptools wheel
python -m pip install "mcp>=1.2.0"
python -m pip install mcp
python -m pip install mcp --timeout 100
python -m pip install mcp -i https://pypi.org/simple
```

Comprobar:

```powershell
python -c "import mcp; print('mcp OK')"
```

**Nota:** Sin `mcp` la app **sí abre**. Solo la pestaña MCP Studio quedará limitada hasta que el paquete esté instalado. El resto (proyectos, JSON, Rojo, Export, Providers) funciona.

Otras dependencias críticas:

```powershell
python -m pip install PySide6 httpx psutil anyio Pygments pathvalidate python-dotenv
```

## 5. Ejecutar la app

### Opción A — doble clic

`run_gsl.bat`

### Opción B — PowerShell

```powershell
.\.venv\Scripts\Activate.ps1
python run.py
```

### Opción C

```powershell
.\run_gsl.ps1
```

## 6. Primera vez

1. Pestaña **Providers** → deja **FREE MODE**
2. Crea un proyecto a la izquierda
3. **Export Center** o **AI Command Center** según necesites
4. **Rojo** solo si tienes `rojo` en el PATH
5. **MCP Studio** solo si instalaste `mcp` y tienes Studio con MCP activo

## Problemas frecuentes

| Error | Solución |
|-------|----------|
| `python` no se reconoce | Reinstala Python con PATH |
| `pip install mcp` 502 / timeout | Reintenta, otra red, o `pip install mcp -i https://pypi.org/simple` |
| No abre ventana | Activa `.venv` y `python run.py`; revisa errores en consola |
| ExecutionPolicy | `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` |
