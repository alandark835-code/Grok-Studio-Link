"""
Connection Manager — manages lifecycle of the MCP STDIO connection to Roblox Studio.
"""

from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import List, Optional

from core.logger import get_logger

log = get_logger()


class ConnectionState(Enum):
    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"


@dataclass
class ConnectionInfo:
    state: ConnectionState = ConnectionState.DISCONNECTED
    message: str = "Desconectado"
    studio_id: Optional[str] = None
    tools_count: int = 0
    command: str = ""
    error_detail: str = ""


def default_mcp_candidates() -> List[List[str]]:
    """
    Possible ways to launch Roblox Studio MCP on Windows.
    Real entry point is typically %LOCALAPPDATA%\\Roblox\\mcp.bat
    """
    candidates: List[List[str]] = []

    local = os.environ.get("LOCALAPPDATA", "")
    if local:
        bat = Path(local) / "Roblox" / "mcp.bat"
        if bat.exists():
            candidates.append(["cmd.exe", "/c", str(bat)])

    for name in ("mcp", "roblox-mcp"):
        path = shutil.which(name)
        if path:
            candidates.append([path])

    return candidates


class ConnectionManager:
    def __init__(self, preferred_command: Optional[List[str]] = None):
        self.info = ConnectionInfo()
        self.preferred_command = preferred_command
        self._process = None

    def status(self) -> ConnectionInfo:
        return self.info

    def set_state(
        self,
        state: ConnectionState,
        message: str = "",
        tools_count: int = 0,
        error_detail: str = "",
        command: str = "",
    ) -> ConnectionInfo:
        self.info = ConnectionInfo(
            state=state,
            message=message or state.value,
            tools_count=tools_count,
            error_detail=error_detail,
            command=command or self.info.command,
        )
        log.info("MCP state → %s | %s", state.value, self.info.message)
        return self.info

    def resolve_command(self) -> Optional[List[str]]:
        if self.preferred_command:
            return list(self.preferred_command)
        candidates = default_mcp_candidates()
        if candidates:
            return candidates[0]
        return None

    def mark_disconnected(self, reason: str = "Desconectado") -> ConnectionInfo:
        self._process = None
        return self.set_state(ConnectionState.DISCONNECTED, reason)

    def mark_error(self, detail: str) -> ConnectionInfo:
        self._process = None
        return self.set_state(ConnectionState.ERROR, "Error de conexión", error_detail=detail)
