"""
MCP Client for GSL 2.0 — STDIO transport to Roblox Studio (or any MCP server).

Uses the official `mcp` Python SDK when installed.
Discovers tools dynamically; never invents tool names.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional

from core.logger import get_logger
from mcp.connection_manager import ConnectionManager, ConnectionState
from mcp.tool_registry import ToolRegistry

log = get_logger()

_MCP_AVAILABLE = False
try:
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client
    _MCP_AVAILABLE = True
except ImportError:
    log.warning("Paquete 'mcp' no instalado. Ejecuta: pip install mcp")


class MCPClient:
    def __init__(self, connection: ConnectionManager):
        self.connection = connection
        self.registry = ToolRegistry()
        self._session: Any = None
        self._context = None

    def is_sdk_available(self) -> bool:
        return _MCP_AVAILABLE

    def connect(self, command: Optional[List[str]] = None) -> Dict[str, Any]:
        if not _MCP_AVAILABLE:
            self.connection.mark_error(
                "El paquete Python 'mcp' no está instalado. Ejecuta: pip install mcp"
            )
            return self._status_dict()

        cmd = command or self.connection.resolve_command()
        if not cmd:
            self.connection.mark_error(
                "No se encontró el ejecutable MCP de Roblox Studio. "
                "Abre Studio → Assistant → Manage MCP Servers → Enable Studio as MCP server. "
                "También puedes configurar la ruta manualmente."
            )
            return self._status_dict()

        self.connection.set_state(
            ConnectionState.CONNECTING,
            f"Conectando: {' '.join(cmd)}",
            command=" ".join(cmd),
        )

        try:
            return self._run(self._async_connect(cmd))
        except Exception as e:
            log.exception("MCP connect failed")
            self.connection.mark_error(str(e))
            self.registry.clear()
            return self._status_dict()

    def disconnect(self) -> Dict[str, Any]:
        try:
            if self._session is not None:
                self._run(self._async_disconnect())
        except Exception as e:
            log.warning("Disconnect error: %s", e)
        finally:
            self._session = None
            self._context = None
            self.registry.clear()
            self.connection.mark_disconnected("Desconectado por el usuario")
        return self._status_dict()

    def list_tools(self) -> List[Dict[str, Any]]:
        if self.connection.status().state != ConnectionState.CONNECTED:
            return []
        return [
            {"name": t.name, "description": t.description, "input_schema": t.input_schema}
            for t in self.registry.all()
        ]

    def call_tool(self, name: str, arguments: Optional[Dict[str, Any]] = None) -> Any:
        if self.connection.status().state != ConnectionState.CONNECTED:
            raise RuntimeError("No hay conexión MCP activa")
        if self.registry.get(name) is None:
            raise RuntimeError(
                f"Herramienta '{name}' no está en el registro. "
                "Solo se pueden llamar tools anunciadas por el servidor."
            )
        return self._run(self._async_call_tool(name, arguments or {}))

    def refresh_tools(self) -> int:
        if self.connection.status().state != ConnectionState.CONNECTED or self._session is None:
            return 0
        count = self._run(self._async_refresh_tools())
        self.connection.info.tools_count = count
        return count

    def _run(self, coro):
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    future = pool.submit(asyncio.run, coro)
                    return future.result(timeout=60)
            return loop.run_until_complete(coro)
        except RuntimeError:
            return asyncio.run(coro)

    async def _async_connect(self, cmd: List[str]) -> Dict[str, Any]:
        server_params = StdioServerParameters(
            command=cmd[0],
            args=cmd[1:] if len(cmd) > 1 else [],
            env=None,
        )
        self._context = stdio_client(server_params)
        read, write = await self._context.__aenter__()
        self._session = ClientSession(read, write)
        await self._session.__aenter__()
        await self._session.initialize()

        tools_result = await self._session.list_tools()
        raw_tools = getattr(tools_result, "tools", tools_result) or []
        count = self.registry.update_from_list(raw_tools)

        self.connection.set_state(
            ConnectionState.CONNECTED,
            f"Conectado — {count} herramienta(s) descubierta(s)",
            tools_count=count,
            command=" ".join(cmd),
        )
        log.info("MCP connected. Tools: %s", self.registry.list_names())
        return self._status_dict()

    async def _async_disconnect(self) -> None:
        if self._session is not None:
            try:
                await self._session.__aexit__(None, None, None)
            except Exception:
                pass
        if self._context is not None:
            try:
                await self._context.__aexit__(None, None, None)
            except Exception:
                pass

    async def _async_refresh_tools(self) -> int:
        tools_result = await self._session.list_tools()
        raw_tools = getattr(tools_result, "tools", tools_result) or []
        return self.registry.update_from_list(raw_tools)

    async def _async_call_tool(self, name: str, arguments: Dict[str, Any]) -> Any:
        result = await self._session.call_tool(name, arguments=arguments)
        if hasattr(result, "content"):
            parts = []
            for block in result.content:
                if hasattr(block, "text"):
                    parts.append(block.text)
                else:
                    parts.append(str(block))
            return "\n".join(parts) if parts else str(result)
        return result

    def _status_dict(self) -> Dict[str, Any]:
        info = self.connection.status()
        return {
            "state": info.state.value,
            "message": info.message,
            "tools_count": info.tools_count,
            "command": info.command,
            "error_detail": info.error_detail,
            "tools": self.registry.list_names(),
            "sdk_available": _MCP_AVAILABLE,
        }
