"""
Tool Registry — stores tools discovered from a live MCP server.
Never invents tool names; only records what the server actually announces.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ToolInfo:
    name: str
    description: str = ""
    input_schema: Dict[str, Any] = field(default_factory=dict)

    def summary(self) -> str:
        desc = self.description.strip() or "(sin descripción)"
        return f"{self.name} — {desc}"


class ToolRegistry:
    def __init__(self):
        self._tools: Dict[str, ToolInfo] = {}

    def clear(self) -> None:
        self._tools.clear()

    def update_from_list(self, tools: List[Any]) -> int:
        """
        Accepts the raw list returned by MCP list_tools.
        Each item may be a dict or an object with name/description/inputSchema.
        """
        self.clear()
        for t in tools:
            if isinstance(t, dict):
                name = t.get("name") or ""
                desc = t.get("description") or ""
                schema = t.get("inputSchema") or t.get("input_schema") or {}
            else:
                name = getattr(t, "name", "") or ""
                desc = getattr(t, "description", "") or ""
                schema = getattr(t, "inputSchema", None) or getattr(t, "input_schema", None) or {}
            if not name:
                continue
            self._tools[name] = ToolInfo(name=name, description=str(desc), input_schema=dict(schema) if schema else {})
        return len(self._tools)

    def list_names(self) -> List[str]:
        return sorted(self._tools.keys())

    def get(self, name: str) -> Optional[ToolInfo]:
        return self._tools.get(name)

    def all(self) -> List[ToolInfo]:
        return [self._tools[k] for k in sorted(self._tools.keys())]

    def __len__(self) -> int:
        return len(self._tools)
