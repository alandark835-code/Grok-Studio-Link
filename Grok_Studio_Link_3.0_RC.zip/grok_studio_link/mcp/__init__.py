# MCP package — stubs for GSL 2.0
