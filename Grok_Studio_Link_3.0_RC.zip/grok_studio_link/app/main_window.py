"""
Main window of GROK STUDIO LINK 3.0 RC
"""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QSplitter,
    QTabWidget, QLabel, QStatusBar, QTextEdit, QVBoxLayout
)

from core.config import AppConfig
from core.security import SecurityManager
from core.project_manager import ProjectManager
from core.backup_manager import BackupManager
from core.task_engine import TaskEngine
from core.ai_provider import AIProviderManager
from core.rojo_manager import RojoManager
from core.resource_monitor import ResourceMonitor
from core.export_manager import ExportManager
from core.zip_inspector import ZipInspector
from core.project_builder import ProjectBuilder
from core.logger import get_logger
from mcp.connection_manager import ConnectionManager
from mcp.client import MCPClient
from modules.explorer import ProjectExplorer
from modules.script_editor import ScriptEditor
from modules.command_center import CommandCenter
from modules.mcp_panel import MCPPanel
from modules.provider_panel import ProviderPanel
from modules.rojo_panel import RojoPanel
from modules.resource_panel import ResourcePanel
from modules.export_panel import ExportPanel
from modules.zip_panel import ZipPanel
from modules.builder_panel import BuilderPanel
from modules.debugger_panel import DebuggerPanel
from modules.playtest_panel import PlaytestPanel
from modules.perf_panel import PerfPanel
from modules.backup_panel import BackupPanel
from modules.settings_panel import SettingsPanel
from app.theme import DARK_STYLESHEET

log = get_logger()


class MainWindow(QMainWindow):
    def __init__(self, config: AppConfig):
        super().__init__()
        self.config = config
        config.version = "3.0.0-rc.1"
        self.setWindowTitle(f"{config.app_name} {config.version}")
        self.resize(max(config.window_width, 1320), max(config.window_height, 900))
        self.setStyleSheet(DARK_STYLESHEET)

        self.security = SecurityManager(
            workspace_root=config.workspace_dir,
            max_task_bytes=config.max_task_bytes,
            max_file_bytes=config.max_file_content_bytes,
            allowed_extensions=config.allowed_extensions,
        )
        self.pm = ProjectManager(config.workspace_dir, self.security)
        self.backups = BackupManager(config.backups_dir)
        self.task_engine = TaskEngine(self.pm, self.security, self.backups)
        self.conn_mgr = ConnectionManager()
        self.mcp = MCPClient(self.conn_mgr)
        self.ai = AIProviderManager(config_path=config.root_dir / "provider_config.json")
        self.rojo = RojoManager()
        self.resources = ResourceMonitor()
        export_dir = config.root_dir / "exports"
        export_dir.mkdir(parents=True, exist_ok=True)
        self.export_manager = ExportManager(
            self.pm, self.ai, self.rojo, self.resources, export_dir
        )
        self.zip_inspector = ZipInspector(self.security)
        self.project_builder = ProjectBuilder(self.rojo)

        self._build_ui()
        self._update_status()

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(8, 8, 8, 8)
        splitter = QSplitter(Qt.Horizontal)

        self.explorer = ProjectExplorer(self.pm)
        self.explorer.file_selected.connect(self._on_file_selected)
        splitter.addWidget(self.explorer)

        self.tabs = QTabWidget()

        dash = QWidget()
        dl = QVBoxLayout(dash)
        t = QLabel("GROK STUDIO LINK 3.0 RC")
        t.setObjectName("title")
        dl.addWidget(t)
        info = QLabel(
            "Release Candidate 1 — herramientas de calidad + Beta completa.\n\n"
            "Arranque Windows: install_deps.bat → run_gsl.bat\n"
            "FREE MODE por defecto · MCP opcional · API HTTP opcional\n\n"
            "Nuevo en RC: Debugger estático · Playtest guiado · Performance · "
            "Backup Center · Settings/Health"
        )
        info.setObjectName("subtitle")
        info.setWordWrap(True)
        dl.addWidget(info)
        dl.addStretch()
        self.tabs.addTab(dash, "Dashboard")

        self.editor = ScriptEditor(self.pm)
        self.tabs.addTab(self.editor, "Editor")
        self.command_center = CommandCenter(self.task_engine)
        self.command_center.task_applied.connect(self._on_task_applied)
        self.tabs.addTab(self.command_center, "AI Command Center")
        self.export_panel = ExportPanel(self.export_manager)
        self.tabs.addTab(self.export_panel, "Export")
        self.zip_panel = ZipPanel(self.zip_inspector, self.pm, self.backups)
        self.tabs.addTab(self.zip_panel, "ZIP")
        self.builder_panel = BuilderPanel(self.project_builder, self.pm)
        self.tabs.addTab(self.builder_panel, "Builder")
        self.debugger_panel = DebuggerPanel(self.pm, self.export_manager)
        self.tabs.addTab(self.debugger_panel, "Debugger")
        self.playtest_panel = PlaytestPanel(self.pm, self.export_manager)
        self.tabs.addTab(self.playtest_panel, "Playtest")
        self.perf_panel = PerfPanel(self.pm)
        self.tabs.addTab(self.perf_panel, "Performance")
        self.provider_panel = ProviderPanel(self.ai)
        self.provider_panel.mode_changed.connect(self._on_provider_changed)
        self.tabs.addTab(self.provider_panel, "Providers")
        self.rojo_panel = RojoPanel(self.rojo, self.pm)
        self.tabs.addTab(self.rojo_panel, "Rojo")
        self.mcp_panel = MCPPanel(self.mcp)
        self.mcp_panel.connection_changed.connect(self._on_mcp_changed)
        self.tabs.addTab(self.mcp_panel, "MCP")
        self.backup_panel = BackupPanel(self.backups, self.pm)
        self.tabs.addTab(self.backup_panel, "Backups")
        self.resource_panel = ResourcePanel(self.resources)
        self.tabs.addTab(self.resource_panel, "Resources")
        self.settings_panel = SettingsPanel(self.config)
        self.tabs.addTab(self.settings_panel, "Settings")
        self.console = QTextEdit()
        self.console.setReadOnly(True)
        self.tabs.addTab(self.console, "Consola")

        splitter.addWidget(self.tabs)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 3)
        root.addWidget(splitter)
        self.status = QStatusBar()
        self.setStatusBar(self.status)

    def _on_file_selected(self, relative_path: str):
        self.editor.open_file(relative_path)
        self.tabs.setCurrentWidget(self.editor)

    def _on_task_applied(self, report):
        self.explorer.refresh_projects()
        self.console.append(f"Tarea → éxito={report.success} ops={len(report.operations)}")
        if not report.success and report.errors:
            try:
                self.export_manager.write_error_report(
                    "Task apply failures", report.errors,
                    extra={"project": report.project},
                )
            except Exception as e:
                log.warning("%s", e)
        self._update_status()

    def _on_mcp_changed(self, status: dict):
        self.console.append(f"MCP → {status.get('state')}")
        self._update_status()

    def _on_provider_changed(self, mode: str):
        self.console.append(f"Provider → {mode}")
        self._update_status()

    def _update_status(self):
        conn = self.conn_mgr.status()
        prov = self.ai.status()
        proj = self.pm.current_project.name if self.pm.current_project else "—"
        self.status.showMessage(
            f"Proyecto: {proj}  |  AI: {prov.label}  |  MCP: {conn.state.value}  |  {self.config.version}"
        )
