"""
Dark professional theme for GROK STUDIO LINK.
"""

from __future__ import annotations

DARK_STYLESHEET = """
QMainWindow, QWidget {
    background-color: #1e1e2e;
    color: #cdd6f4;
    font-family: "Segoe UI", "Ubuntu", sans-serif;
    font-size: 13px;
}

QMenuBar {
    background-color: #181825;
    color: #cdd6f4;
}

QMenuBar::item:selected {
    background-color: #313244;
}

QMenu {
    background-color: #181825;
    color: #cdd6f4;
    border: 1px solid #45475a;
}

QMenu::item:selected {
    background-color: #45475a;
}

QToolBar {
    background-color: #181825;
    border: none;
    spacing: 4px;
    padding: 4px;
}

QPushButton {
    background-color: #313244;
    color: #cdd6f4;
    border: 1px solid #45475a;
    border-radius: 6px;
    padding: 6px 14px;
    min-height: 20px;
}

QPushButton:hover {
    background-color: #45475a;
}

QPushButton:pressed {
    background-color: #585b70;
}

QPushButton#primary {
    background-color: #89b4fa;
    color: #1e1e2e;
    font-weight: bold;
    border: none;
}

QPushButton#primary:hover {
    background-color: #b4befe;
}

QPushButton#danger {
    background-color: #f38ba8;
    color: #1e1e2e;
    border: none;
}

QLineEdit, QPlainTextEdit, QTextEdit, QComboBox {
    background-color: #313244;
    color: #cdd6f4;
    border: 1px solid #45475a;
    border-radius: 4px;
    padding: 4px 8px;
    selection-background-color: #89b4fa;
    selection-color: #1e1e2e;
}

QTreeWidget, QListWidget, QTableWidget {
    background-color: #181825;
    color: #cdd6f4;
    border: 1px solid #45475a;
    border-radius: 4px;
    alternate-background-color: #1e1e2e;
}

QTreeWidget::item:selected, QListWidget::item:selected {
    background-color: #45475a;
}

QHeaderView::section {
    background-color: #313244;
    color: #cdd6f4;
    border: none;
    padding: 6px;
}

QStatusBar {
    background-color: #181825;
    color: #a6adc8;
}

QSplitter::handle {
    background-color: #45475a;
}

QLabel#title {
    font-size: 18px;
    font-weight: bold;
    color: #89b4fa;
}

QLabel#subtitle {
    color: #a6adc8;
}

QTabWidget::pane {
    border: 1px solid #45475a;
    background-color: #1e1e2e;
}

QTabBar::tab {
    background-color: #313244;
    color: #cdd6f4;
    padding: 8px 16px;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
    margin-right: 2px;
}

QTabBar::tab:selected {
    background-color: #45475a;
    color: #89b4fa;
}

QScrollBar:vertical {
    background: #181825;
    width: 10px;
}

QScrollBar::handle:vertical {
    background: #45475a;
    border-radius: 5px;
    min-height: 20px;
}

QGroupBox {
    border: 1px solid #45475a;
    border-radius: 6px;
    margin-top: 12px;
    padding-top: 8px;
}

QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
    color: #89b4fa;
}
"""
