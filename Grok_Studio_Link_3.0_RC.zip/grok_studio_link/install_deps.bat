@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo === GROK STUDIO LINK — instalar dependencias ===

where python >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Python no esta en el PATH. Instala Python 3.12 y marca "Add to PATH".
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creando entorno virtual .venv ...
  python -m venv .venv
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip setuptools wheel
echo.
echo Instalando requirements...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo [AVISO] Fallo parcial. Intentando paquetes base + mcp por separado...
  python -m pip install "PySide6>=6.6.0" "httpx>=0.27.0" "psutil>=5.9.0" "anyio>=4.0.0" Pygments pathvalidate python-dotenv
  python -m pip install "mcp>=1.2.0"
  if errorlevel 1 (
    echo [AVISO] mcp no se pudo instalar ahora. La app funcionara sin pestaña MCP completa.
  )
)

echo.
echo Comprobaciones:
python -c "import PySide6; print('PySide6 OK')"
python -c "import mcp; print('mcp OK')" 2>nul || echo mcp NO instalado (opcional para MCP Studio)
python -c "import httpx; print('httpx OK')"
echo.
echo Listo. Ejecuta run_gsl.bat
pause
